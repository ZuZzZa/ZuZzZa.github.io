#!/usr/bin/env python3
"""Exercises the live-usage path with a stubbed endpoint.

No credential store is touched and no network call is made: the reader and the
request are both replaced. State is redirected to a temporary directory - an
earlier version of this test wrote stub reset times into the real calibration
file and made the panel read 3.5%.

    python3 host/test_live.py
"""
import datetime as dt
import json
import os
import shutil
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import desktop_usage                                       # noqa: E402
import live_usage                                          # noqa: E402
import meter                                               # noqa: E402
from usage import Scanner                                  # noqa: E402

# Relative, not fixed. These were once literal dates, and the day they went
# past the test started failing on any machine with no transcripts to roll a
# stale session window forward from - which is to say, on CI and nowhere else.
SESSION_MINS = 137
WEEK_MINS = 4 * 24 * 60 + 15


def _in(minutes):
    return (dt.datetime.now(dt.timezone.utc)
            + dt.timedelta(minutes=minutes)).isoformat()


# The older shape: three separate top-level keys. Kept as the stub for the
# main run because the fallback path still has to work.
STUB = {
    "five_hour":      {"utilization": 21.0, "resets_at": _in(SESSION_MINS)},
    "seven_day":      {"utilization": 46.0, "resets_at": _in(WEEK_MINS)},
    "seven_day_opus": {"utilization": 78.0, "resets_at": _in(WEEK_MINS)},
    "extra_usage":    {"ignored": True},
}

# What the endpoint actually returns now. seven_day_opus is null and there is
# no seven_day_fable at all, so a reader that only knows the old shape finds
# no model-scoped bucket and quietly falls back to a local guess - which is
# precisely what put a wrong 0% on the panel for a week.
STUB_LIMITS = {
    "five_hour":      {"utilization": 29.0, "resets_at": _in(SESSION_MINS)},
    "seven_day":      {"utilization": 20.0, "resets_at": _in(WEEK_MINS)},
    "seven_day_opus": None,
    "nimbus_quill":   {"utilization": 0.0},
    "limits": [
        {"kind": "session", "group": "session", "percent": 29,
         "resets_at": _in(SESSION_MINS), "scope": None, "is_active": True},
        {"kind": "weekly_all", "group": "weekly", "percent": 20,
         "resets_at": _in(WEEK_MINS), "scope": None, "is_active": False},
        {"kind": "weekly_scoped", "group": "weekly", "percent": 25,
         "resets_at": _in(WEEK_MINS), "is_active": False,
         "scope": {"model": {"id": None, "display_name": "Fable"},
                   "surface": None}},
    ],
}

failures = []


def check(cond, msg):
    if not cond:
        failures.append(msg)
    print("  %s %s" % ("ok  " if cond else "FAIL", msg))


def silence_desktop():
    """The desktop cache is a second source; mute it to test the others alone."""
    desktop_usage.latest = lambda now=None: None


def stub_desktop():
    """A synthetic cache reading, so the test does not depend on this machine
    having Claude Desktop installed - CI runs it on Linux."""
    import datetime as dt
    desktop_usage.latest = lambda now=None: {
        "session": 21.0, "week": 46.0, "fresh": True, "age_s": 120.0,
        "at": (now or dt.datetime.now(dt.timezone.utc)) - dt.timedelta(minutes=2),
    }


def reset_cache():
    live_usage._cache.update(data=None, fetched=0.0, next_try=0.0,
                             backoff=0.0, error=None)


def main():
    sandbox = tempfile.mkdtemp(prefix="cum-test-")
    meter.STATE_DIR = sandbox
    meter.CALIB_PATH = os.path.join(sandbox, "calib.json")

    scanner = Scanner()
    scanner.poll()
    real_latest = desktop_usage.latest

    try:
        print("bucket mapping")
        mapped = live_usage.buckets(STUB)
        check(set(mapped) == {"session", "week", "fable"},
              "all three buckets recognised, extra_usage ignored")
        check(mapped["fable"]["utilization"] == 78.0,
              "the model-specific weekly bucket maps to fable")

        print("the limits array, which is where the scoped bucket lives")
        m = live_usage.buckets(STUB_LIMITS)
        check(set(m) == {"session", "week", "fable"},
              "all three buckets come from limits[]")
        util = lambda k: (m.get(k) or {}).get("utilization")
        check(util("fable") == 25.0,
              "the model-scoped weekly is read, not the null seven_day_opus")
        check(util("session") == 29.0 and util("week") == 20.0,
              "limits[] wins over the top-level keys")
        check(live_usage.scoped_model_name(STUB_LIMITS) == "Fable",
              "the scoped model names itself, so a relabel is detectable")
        check(live_usage.scoped_model_name(STUB) is None,
              "and is absent in the older shape rather than guessed")

        print("endpoint reachable")
        live_usage._read_token = lambda: "stub"
        live_usage._request = lambda token: STUB
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["live"] is True and s["conf"] == meter.CONF_LIVE,
              "reported as live, confidence %d" % s["conf"])
        check(abs(s["sess_pct"] - 21.0) < 0.01
              and abs(s["wk_pct"] - 46.0) < 0.01
              and abs(s["fb_pct"] - 78.0) < 0.01,
              "percentages come straight from the endpoint")
        # Not merely positive: the countdown has to be the one the payload
        # asked for. Anything else means it came from a local guess that
        # happened to be in the future.
        check(SESSION_MINS - 2 <= s["sess_reset"] <= SESSION_MINS
              and WEEK_MINS - 2 <= s["wk_reset"] <= WEEK_MINS,
              "reset countdowns adopted from the payload (%d, %d min; "
              "wanted %d, %d)" % (s["sess_reset"], s["wk_reset"],
                                  SESSION_MINS, WEEK_MINS))

        print("endpoint unavailable, desktop cache present")
        live_usage._read_token = lambda: None
        stub_desktop()
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["source"] == "desktop cache",
              "falls through to the desktop cache, not to guesswork")

        print("the five-hour window turns over")
        # For the two minutes a payload stays cached after the window rolls it
        # still names the old instant, now in the past. Serving that is worse
        # than serving nothing: downstream rolls a passed reset forward by
        # guesswork and counts down to a boundary Claude never mentioned.
        calls = {"n": 0}

        def fresh(token):
            calls["n"] += 1
            return {"limits": [{"kind": "session", "percent": 4,
                                "resets_at": _in(300)}]}

        live_usage._read_token = lambda: "stub"
        live_usage._request = fresh
        reset_cache()
        live_usage._cache.update({
            "data": {"limits": [{"kind": "session", "percent": 97,
                                 "resets_at": _in(-3)}]},
            "fetched": time.monotonic(), "next_try": 0.0,
            "backoff": 0.0, "error": None})
        served, _ = live_usage.fetch()
        row = [r for r in served["limits"] if r["kind"] == "session"][0]
        check(calls["n"] == 1 and row["percent"] == 4,
              "a payload whose window has passed is refetched, not served")
        calls["n"] = 0
        live_usage._cache["fetched"] = time.monotonic()
        live_usage.fetch()
        check(calls["n"] == 0,
              "and one whose window is still open is still served from cache")

        print("the endpoint drops out mid-window")
        # 429s are routine on this endpoint. What must not happen is the
        # model-scoped bucket quietly reverting to whatever a human last typed
        # days ago - the last reported figure is the better anchor.
        live_usage._read_token = lambda: "stub"
        live_usage._request = lambda token: STUB_LIMITS
        reset_cache()
        before = meter.snapshot(scanner)
        check(abs(before["fb_pct"] - 25.0) < 0.01,
              "reported 25%% while the endpoint answered (%.1f%%)" % before["fb_pct"])
        live_usage._read_token = lambda: None
        silence_desktop()
        reset_cache()
        after = meter.snapshot(scanner)
        check(abs(after["fb_pct"] - before["fb_pct"]) < 2.0,
              "holds near the last reported figure once it stops answering "
              "(%.1f%% -> %.1f%%)" % (before["fb_pct"], after["fb_pct"]))
        # And say why it held: the reported figure has to have been written
        # down as an anchor. Without this the check above passes on a local
        # estimate that happens to land in the same place.
        calib = json.load(open(os.path.join(meter.STATE_DIR, "calib.json")))
        anchor = (calib.get("buckets", {}).get("fable", {}).get("anchor") or {})
        check(anchor.get("from") == "endpoint"
              and abs(anchor.get("pct", -1) - 25.0) < 0.01,
              "because the reported figure was recorded as the anchor (%r)"
              % {k: anchor.get(k) for k in ("pct", "from")})

        print("neither source available")
        silence_desktop()
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["live"] is False, "falls back instead of failing")
        check(s["sess_pct"] >= 0, "still produces a figure (%.1f%%)" % s["sess_pct"])

        print("endpoint erroring, no desktop cache either")
        live_usage._read_token = lambda: "stub"

        def explode(token):
            raise RuntimeError("simulated 429")

        live_usage._request = explode
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["live"] is False, "an error is soft, not fatal")
        check("429" in s["live_note"], "the reason is reported: %s" % s["live_note"])

        print("state isolation")
        real = os.path.expanduser("~/.claude-usage-meter/calib.json")
        if os.path.exists(real):
            with open(real) as fh:
                live_reset = json.load(fh).get("session_reset")
            check(live_reset != STUB["five_hour"]["resets_at"],
                  "the real calibration file was left alone")
        else:
            check(True, "no real calibration file on this machine, nothing to disturb")
    finally:
        desktop_usage.latest = real_latest
        shutil.rmtree(sandbox, ignore_errors=True)

    print()
    if failures:
        print("FAILED: %d" % len(failures))
        return 1
    print("all checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
