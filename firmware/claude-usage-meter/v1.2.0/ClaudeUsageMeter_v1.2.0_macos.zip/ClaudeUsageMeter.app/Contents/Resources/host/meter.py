"""Turns raw usage events into the numbers shown on the panel.

Anthropic does not expose limits locally, and the transcripts under
~/.claude/projects only cover Claude Code - regular Claude chats on the web,
in the desktop app or on a phone eat the same allowance and leave nothing
here to read. So the local measurement is a *lower bound* on real usage, and
no formula over it can reproduce the reported percentage.

What works instead is anchoring. Each calibration records the reported
percentage together with what we could see at that moment; between
calibrations we add only the change we can observe:

    pct = pct_at_anchor + (visible_now - visible_at_anchor) / limit * 100

That is exact for work done through Claude Code and silently low for anything
done elsewhere, which is the honest failure mode - it under-reports rather
than inventing headroom.

`limit` itself comes from two readings in the same window:

    limit = change_in_visible / change_in_percent

The UI reports whole percents, so a change of one or two points is mostly
rounding noise; a refit is only accepted past MIN_FIT_POINTS. Fitting the
5-hour ceiling this way gave $661 where a single-reading estimate had said
$310 - the error a proportional model was quietly carrying.
"""
import os
import json
import time
import datetime as dt
from collections import defaultdict

import desktop_usage
import live_usage
from usage import five_hour_blocks, short_model, BLOCK_HOURS, WEEK_DAYS

STATE_DIR = os.path.expanduser("~/.claude-usage-meter")
CALIB_PATH = os.path.join(STATE_DIR, "calib.json")
ATTENTION_DIR = os.path.join(STATE_DIR, "attention")
ATTENTION_LEGACY = os.path.join(STATE_DIR, "attention.json")
ATTENTION_MAX_AGE = 3600     # a marker this old outlived whatever set it
CONFIG_PATH = os.path.join(STATE_DIR, "config.json")

DEFAULT_CONFIG = {
    "night_start": 22,       # local hour the panel dims at
    "night_end": 7,          # local hour it brightens again
    "notify_at": [75, 90],   # percentages worth a macOS notification
    # The green "finished" blink. Set false and it never appears; the red
    # "blocked on you" one is not affected, because that is the alert you
    # cannot afford to switch off by accident.
    "alert_done": True,
}
HISTORY_DAYS = 7

SEEDS = {"session": 300.0, "week": 1500.0, "fable": 500.0}


def ceiling_floor(visible, pct):
    """The lowest a ceiling can possibly be, given one reading.

    Spend we cannot see only ever adds, so true spend >= visible and
    ceiling = spend / pct >= visible / pct. A fitted ceiling under this is not
    merely doubtful, it is arithmetically impossible.
    """
    return (visible / (pct / 100.0)) if pct and pct > 0 and visible > 0 else 0.0
# Percentages arrive as whole numbers, so a delta of N points carries up to
# a full point of rounding error - a third of the answer at N=3. Ten points
# keeps that under 10%, which is the difference between a ceiling that is
# roughly right and one that is off by twenty times.
MIN_FIT_POINTS = 10
FRESH_HOURS = 6           # an anchor older than this stops claiming high confidence

IDLE, ACTIVE, WARN, CRIT, LIMITED = 0, 1, 2, 3, 4
CONF_LOCAL_MAX = 3
CONF_LIVE = 4             # reported by Claude itself, not inferred
BUCKETS = ("session", "week", "fable")
LABELS = {"session": "5-hour", "week": "Week all", "fable": "Week Fable"}


def is_fable(model):
    return "fable" in (model or "")


def load_config():
    """User-tunable bits that are not calibration - night hours, notify levels.

    Written out with the defaults on first run: a settings file you can see is
    worth more than one documented somewhere else.
    """
    cfg = dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_PATH) as fh:
            user = json.load(fh)
        if isinstance(user, dict):
            cfg.update({k: v for k, v in user.items() if k in DEFAULT_CONFIG})
        return cfg
    except ValueError:
        return cfg                       # malformed: fall back, do not clobber
    except OSError:
        pass
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w") as fh:
            json.dump(DEFAULT_CONFIG, fh, indent=2, sort_keys=True)
    except OSError:
        pass
    return cfg


def _cfg_alert_done():
    """Whether the green "finished" alert is wanted at all.

    Muting from the panel is deliberately temporary - a changed count lifts
    it, so a session blocked on you cannot be silenced for good. That is the
    right rule for red and the wrong one for green, which came back every time
    any other session finished. This switch is the permanent one, and it takes
    finished sessions out of the count as well as out of the colour: with it
    off, three finished sessions and one waiting is "NEEDS YOU", not x4.
    """
    try:
        return bool(load_config().get("alert_done", True))
    except Exception:
        return True


def attention(now=None, include_done=True):
    """-> (count, what, kind). One marker per session, from attention_hook.py.

    kind is 1 when anything is blocked on the user and 2 when everything
    live has merely finished - the panel paints those red and green.

    A marker is removed when that session is answered, so the count is simply
    how many are still there. The age cap covers a session that died with a
    prompt open - otherwise the panel would blink forever.
    """
    paths = []
    try:
        paths = [os.path.join(ATTENTION_DIR, f)
                 for f in os.listdir(ATTENTION_DIR) if f.endswith(".json")]
    except OSError:
        pass
    if os.path.exists(ATTENTION_LEGACY):      # marker from before per-session files
        paths.append(ATTENTION_LEGACY)

    now_ts = time.time()
    live = []
    for path in paths:
        try:
            with open(path) as fh:
                doc = json.load(fh)
        except (OSError, ValueError):
            continue
        at = doc.get("at")
        if isinstance(at, (int, float)) and now_ts - at <= ATTENTION_MAX_AGE:
            live.append((at, str(doc.get("what", ""))[:120],
                         str(doc.get("kind") or "waiting")))
    if not include_done:
        live = [e for e in live if e[2] != "done"]
    if not live:
        return 0, "", 0
    live.sort()
    # Red outranks green. One session blocked on a dialog matters more than
    # three that have finished, and a single colour has to pick the urgent one.
    kind = 1 if any(k != "done" for _, _, k in live) else 2
    return len(live), live[-1][1], kind


def is_night(cfg, now):
    """Local-clock night, handling the usual wrap past midnight."""
    hour = now.astimezone().hour
    start, end = int(cfg["night_start"]) % 24, int(cfg["night_end"]) % 24
    return (start <= hour or hour < end) if start > end else (start <= hour < end)


def pace(pct, start, reset, now):
    """How far ahead of the window's own clock the spending is, in percent.

    100 means exactly on schedule: half the window gone, half the budget used.
    128 means burning 28% faster than the window elapses. Early in a window the
    ratio is meaningless, so it reports on-pace until enough of it has passed.
    """
    if not start or not reset:
        return 100
    span = (reset - start).total_seconds()
    gone = (now - start).total_seconds()
    if span <= 0 or gone <= 0:
        return 100
    frac = gone / span
    if frac < 0.05:
        return 100
    return max(0, min(999, int(round(pct / (frac * 100.0) * 100))))


def daily_history(events, now, days=HISTORY_DAYS):
    """-> ([spend per local day, oldest first], weekday index of the last day).

    Local days, because "yesterday" means the day you lived through, not a UTC
    boundary. The last entry is today and is still filling up.
    """
    local = now.astimezone()
    tz = local.tzinfo
    midnight = local.replace(hour=0, minute=0, second=0, microsecond=0)
    out = []
    for back in range(days - 1, -1, -1):
        lo = midnight - dt.timedelta(days=back)
        hi = lo + dt.timedelta(days=1)
        out.append(sum(c for t, _, _, c in events
                       if lo <= t.astimezone(tz) < hi))
    return out, local.weekday()


def load_calib():
    try:
        with open(CALIB_PATH) as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        data = {}
    data.setdefault("buckets", {})
    data.setdefault("readings", [])
    for key in BUCKETS:
        data["buckets"].setdefault(key, {})
    return data


def save_calib(data):
    os.makedirs(STATE_DIR, exist_ok=True)
    tmp = CALIB_PATH + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
    os.replace(tmp, CALIB_PATH)


def _iso(t):
    return t.astimezone(dt.timezone.utc).isoformat()


def _parse(s):
    try:
        return dt.datetime.fromisoformat(s) if s else None
    except (TypeError, ValueError):
        return None


def same_window(a, b, tol_min=20):
    """Window identity, compared with slack.

    A window is keyed by its reset instant, but the usage screen reports the
    time remaining rounded to whole minutes, so two readings of the *same*
    window land a few minutes apart. Exact matching would silently treat every
    reading as a fresh window and never fit a ceiling.
    """
    ta, tb = _parse(a), _parse(b)
    if ta is None or tb is None:
        return bool(a) and a == b
    return abs((ta - tb).total_seconds()) <= tol_min * 60


def visible_cost(events, lo, hi=None, only_fable=False):
    return sum(c for t, m, _, c in events
               if t >= lo and (hi is None or t < hi)
               and (not only_fable or is_fable(m)))


# ---------------------------------------------------------------- windows

def _roll_session(reset, events, now):
    """Advance a stale session anchor: a new window opens on the next request."""
    while reset is not None and reset <= now:
        nxt = next((t for t, _, _, _ in events if t >= reset), None)
        if nxt is None:
            return None
        reset = nxt + dt.timedelta(hours=BLOCK_HOURS)
    return reset


def windows(data, events, now):
    """-> {bucket: (start, reset_or_None)} for the live windows."""
    sess_reset = _roll_session(_parse(data.get("session_reset")), events, now)
    if sess_reset:
        sess_start = sess_reset - dt.timedelta(hours=BLOCK_HOURS)
    else:
        blocks = five_hour_blocks(events)
        cur = blocks[-1] if blocks and blocks[-1]["end"] > now else None
        sess_start = cur["start"] if cur else now
        sess_reset = cur["end"] if cur else None

    wk_reset = _parse(data.get("week_reset"))
    while wk_reset is not None and wk_reset <= now:
        wk_reset += dt.timedelta(days=WEEK_DAYS)
    wk_start = (wk_reset - dt.timedelta(days=WEEK_DAYS)) if wk_reset \
        else now - dt.timedelta(days=WEEK_DAYS)

    return {"session": (sess_start, sess_reset),
            "week": (wk_start, wk_reset),
            "fable": (wk_start, wk_reset)}


def measure(events, win):
    return {"session": visible_cost(events, win["session"][0]),
            "week": visible_cost(events, win["week"][0]),
            "fable": visible_cost(events, win["fable"][0], only_fable=True)}


# ---------------------------------------------------------------- calibration

def calibrate(events, session, week, fable, now=None):
    """Records one reading of the Claude usage screen and refits what it can.

    `session` and `week` are (percent, minutes-to-reset); `fable` is a percent
    and shares the weekly reset.
    """
    now = now or dt.datetime.now(dt.timezone.utc)
    data = load_calib()

    if session and session[1]:
        data["session_reset"] = _iso(now + dt.timedelta(minutes=session[1]))
    if week and week[1]:
        data["week_reset"] = _iso(now + dt.timedelta(minutes=week[1]))

    win = windows(data, events, now)
    seen = measure(events, win)
    reported = {"session": session[0] if session else None,
                "week": week[0] if week else None,
                "fable": fable if fable is not None else None}

    report = {}
    for key in BUCKETS:
        pct = reported[key]
        if pct is None:
            continue
        entry = data["buckets"][key]
        window_id = _iso(win[key][1]) if win[key][1] else ""
        prior = entry.get("anchor")

        fitted = None
        if prior and same_window(prior.get("window"), window_id):
            d_pct = pct - prior["pct"]
            d_vis = seen[key] - prior["visible"]
            if (d_pct >= MIN_FIT_POINTS and d_vis > 0
                    and d_vis / (d_pct / 100.0)
                        >= ceiling_floor(seen[key], pct) * 0.95):
                fitted = d_vis / (d_pct / 100.0)
                entry["limit"] = round(fitted, 2)
                entry["limit_from"] = "two readings %.0f%% apart" % d_pct

        entry.setdefault("limit", SEEDS[key])
        entry["anchor"] = {"t": _iso(now), "visible": round(seen[key], 2),
                           "pct": float(pct), "window": window_id}
        report[key] = {"visible": seen[key], "pct": pct,
                       "limit": entry["limit"], "fitted": fitted}

    data["readings"].append(
        {"t": _iso(now),
         **{k: {"visible": round(seen[k], 2), "pct": reported[k]}
            for k in BUCKETS if reported[k] is not None}})
    data["readings"] = data["readings"][-50:]
    data["calibrated_at"] = _iso(now)
    save_calib(data)
    return report


# ---------------------------------------------------------------- snapshot

def _top(mapping, n, namer=lambda x: x):
    total = sum(mapping.values()) or 1.0
    rows = sorted(mapping.items(), key=lambda kv: -kv[1])[:n]
    return [(namer(k), int(round(100.0 * v / total)), v) for k, v in rows if v > 0]


BURN_WINDOW_S = 3600 * 2      # how far back a percentage-derived rate looks
BURN_MIN_SPAN_S = 2700        # and how far apart the two ends must be
SAMPLE_GAP_S = 300            # record where things stand at least this often
SERIES_MAX = 48               # 48 x 5 min covers four hours


def _track(data, key, pct, window_id, now):
    """Keep a short series of reported percentages for this window.

    Only what Claude reports goes in here. Percentages are whole numbers, so
    two samples close together say nothing - the span check below is what
    keeps a single point of rounding from being read as a burst.
    """
    entry = data["buckets"].setdefault(key, {})
    series = entry.get("series") or []
    if series and not same_window((series[-1] or {}).get("window"), window_id):
        series = []
    # Record on change, and otherwise every few minutes anyway. Recording only
    # changes leaves the last point sitting wherever the percentage last moved,
    # so an hour of idleness reads as though the rate never dropped - and a
    # bucket that has held steady all day never gets a second point at all.
    ts = now.timestamp()
    if (not series or abs(series[-1]["pct"] - pct) > 0.001
            or ts - series[-1]["t"] >= SAMPLE_GAP_S):
        series.append({"t": ts, "pct": float(pct), "window": window_id})
        entry["series"] = series[-SERIES_MAX:]
        return True
    return False


def _burn_from_series(data, key, limit, now):
    """Dollars per hour from how the reported percentage moved, or None.

    Measuring spend from transcripts misses everything done elsewhere - the
    phone app above all - so a rate built from them understates, and the limit
    ETA that follows says there is more room than there is. The percentage
    counts all of it.
    """
    series = (data["buckets"].get(key, {}) or {}).get("series") or []
    if len(series) < 2 or not limit:
        return None
    cutoff = now.timestamp() - BURN_WINDOW_S
    live = [s for s in series if s["t"] >= cutoff]
    if len(live) < 2:
        return None
    span = live[-1]["t"] - live[0]["t"]
    if span < BURN_MIN_SPAN_S:
        return None
    d_pct = live[-1]["pct"] - live[0]["pct"]
    if d_pct <= 0:
        return 0.0
    return (d_pct / 100.0) * limit / (span / 3600.0)


def _eta(remaining, burn_hr, cap_min):
    if burn_hr <= 0.01 or remaining <= 0:
        return 0 if remaining <= 0 else -1
    mins = int(remaining / burn_hr * 60)
    return mins if mins < cap_min else -1


def _apply_live_resets(data, live):
    """The endpoint reports the real reset instants; adopt them so the local
    cost windows line up with the buckets the percentages describe."""
    changed = False
    for key, field in (("session", "session_reset"), ("week", "week_reset")):
        at = live.get(key, {}).get("resets_at")
        if not at:
            continue
        parsed = _parse(at)
        if parsed is None:
            continue
        prior = _parse(data.get(field))
        if prior is None or abs((parsed - prior).total_seconds()) > 120:
            data[field] = _iso(parsed)
            changed = True
    return changed


def _auto_fit(data, key, pct, visible, window_id):
    """Two live readings in one window give the ceiling for free.

    The percentages arrive continuously now, so the dollar ceilings no longer
    need a human reading them off a screen - they converge on their own.
    """
    entry = data["buckets"].setdefault(key, {})
    auto = entry.get("auto")
    if auto and same_window(auto.get("window"), window_id):
        d_pct = pct - auto["pct"]
        d_vis = visible - auto["visible"]
        if d_pct >= MIN_FIT_POINTS and d_vis > 0:
            fitted = d_vis / (d_pct / 100.0)
            # Differencing cancels a constant amount of unseen spend, which is
            # why it beats a single reading - but it cannot produce a ceiling
            # below what this very reading already proves. When it does, the
            # lever was too short or the unseen spend is not constant.
            if fitted < ceiling_floor(visible, pct) * 0.95:
                return False
            prior = entry.get("limit") or 0
            entry["limit"] = round(fitted, 2)
            entry["limit_from"] = "live readings %.0f%% apart" % d_pct
            # The baseline deliberately stays put. Advancing it to each new
            # reading holds every future delta down to the gap between two
            # consecutive samples, so the lever never grows and the fit never
            # improves. Keeping the window's first reading lets it lengthen.
            return abs(fitted - prior) > max(1.0, prior * 0.02)
        return False
    entry["auto"] = {"pct": pct, "visible": visible, "window": window_id}
    return True


def snapshot(scanner, now=None):
    now = now or dt.datetime.now(dt.timezone.utc)
    events = scanner.events
    data = load_calib()

    # Source order: the OAuth endpoint if it answers (instant, all three
    # buckets), otherwise the figures Claude Desktop already caches on disk
    # (two buckets, up to 15 minutes stale, no credentials involved).
    live_raw, live_err = live_usage.fetch()
    live = live_usage.buckets(live_raw) if live_raw else {}
    dirty = _apply_live_resets(data, live) if live else False

    win = windows(data, events, now)
    seen = measure(events, win)

    desk = desktop_usage.latest(now)
    source = "endpoint" if live else ("desktop cache" if desk and desk["fresh"]
                                      else "local estimate")
    desk_anchor = {}
    if desk and desk["fresh"]:
        for key, field, only_fable in (("session", "session", False),
                                       ("week", "week", False)):
            pct = desk.get(field)
            if pct is None or key in live:
                continue
            start = win[key][0]
            fit = desktop_usage.fit_ceiling(
                events, since=start, now=now,
                field="fh" if key == "session" else "sd", only_fable=only_fable)
            entry = data["buckets"].setdefault(key, {})
            if fit:
                ceiling, span, r = fit
                if r >= 0.9 and abs(ceiling - (entry.get("limit") or 0)) > 1.0:
                    entry["limit"] = round(ceiling, 2)
                    entry["limit_from"] = ("desktop history, %.0f points, r=%.3f"
                                           % (span, r))
                    dirty = True
            desk_anchor[key] = {
                "pct": float(pct),
                "visible": visible_cost(events, start, desk["at"]),
            }

    anchored_all, oldest_anchor = True, None
    # The badge describes the weakest bucket on screen, not the best one.
    # Requiring only session and week used to let the panel print "live" over
    # a Fable figure nobody had reported - the desktop cache carries fh and sd
    # and nothing else, so that third number is always inferred here. Two
    # trustworthy numbers do not make a trustworthy screen; the per-bucket
    # mask below is what says which of them came from Claude.
    live_keys = set(live) | set(desk_anchor)
    live_all = set(BUCKETS).issubset(live_keys)
    out = {}
    for key in BUCKETS:
        entry = data["buckets"].get(key, {})
        limit = entry.get("limit") or SEEDS[key]
        # A stored ceiling can be left over from a fit made before the guards
        # above existed, or from a window that has since rolled. Repair it
        # here rather than letting it drive a nonsense limit ETA.
        floor = ceiling_floor(seen[key], live[key]["utilization"]
                              if key in live else 0)
        if floor and limit < floor:
            limit = round(floor, 2)
            entry["limit"] = limit
            entry["limit_from"] = "raised to what the reported percent implies"
            dirty = True
        anchor = entry.get("anchor")
        window_id = _iso(win[key][1]) if win[key][1] else ""

        if key in live:
            pct = float(live[key]["utilization"])
            if _auto_fit(data, key, pct, seen[key], window_id):
                dirty = True
            limit = data["buckets"][key].get("limit") or limit
            # A reported percentage is exactly what an anchor is, so record it
            # as one. The endpoint does drop out - 429s are routine on it - and
            # when it does, the model-scoped bucket has nothing else to stand
            # on. Without this it falls back to whatever a human last typed,
            # which by then can be days old and half the true figure.
            prior = entry.get("anchor") or {}
            if (abs(prior.get("pct", -1) - pct) > 0.01
                    or not same_window(prior.get("window"), window_id)):
                data["buckets"].setdefault(key, entry)["anchor"] = {
                    "t": _iso(now), "visible": round(seen[key], 2),
                    "pct": pct, "window": window_id, "from": "endpoint"}
                dirty = True
        elif key in desk_anchor:
            # Anchored to Claude's own sample, extrapolated with measured spend
            # for the minutes since it was taken.
            limit = data["buckets"][key].get("limit") or limit
            a = desk_anchor[key]
            pct = a["pct"] + (seen[key] - a["visible"]) / limit * 100.0
        elif anchor and same_window(anchor.get("window"), window_id):
            pct = anchor["pct"] + (seen[key] - anchor["visible"]) / limit * 100.0
            at = _parse(anchor["t"])
            if at and (oldest_anchor is None or at < oldest_anchor):
                oldest_anchor = at
        else:
            # Fresh window: the hidden share of it is unknown, so this is the
            # visible floor rather than a reading.
            pct = seen[key] / limit * 100.0 if limit else 0.0
            anchored_all = False


        reset = win[key][1]
        # Spend follows the reported percentage, not the transcripts. What
        # this machine can see is only part of the story - work done in the
        # phone app never appears here - so measured spend understates, and
        # by a lot: 28% of the Fable window read $227 measured against $576
        # implied. Where Claude has told us the percentage, the percentage is
        # the honest basis for the money too. Where it has not, all we have is
        # what we measured.
        reported = key in live or key in desk_anchor
        if reported and _track(data, key, pct, window_id, now):
            dirty = True
        cost = (limit * max(0.0, pct) / 100.0) if (reported and limit) \
            else seen[key]
        out[key] = {
            "pct": max(0.0, pct),
            "cost": cost,
            "cost_measured": seen[key],
            "limit": limit,
            # A seeded ceiling is a guess; showing "$300 of $1500" would dress
            # it up as a measurement. Callers show the spend alone instead.
            "limit_known": bool(data["buckets"].get(key, {}).get("limit_from")),
            # -1, not 0: no window is running. Zero would read as "resets any
            # moment now", which is the opposite of what it means.
            "reset": int((reset - now).total_seconds() // 60) if reset else -1,
        }

    if dirty:
        save_calib(data)

    # ---- confidence -----------------------------------------------------
    if live_all:
        conf = CONF_LIVE
    elif not data.get("calibrated_at"):
        conf = 0
    elif not anchored_all:
        conf = 1
    elif oldest_anchor and (now - oldest_anchor).total_seconds() > FRESH_HOURS * 3600:
        conf = 2
    else:
        conf = 3

    # ---- burn rate and time to the binding ceiling ----------------------
    recent = [e for e in events if (now - e[0]).total_seconds() <= 900]
    burn_hr = sum(e[3] for e in recent) * 4.0
    fb_burn = sum(e[3] for e in recent if is_fable(e[1])) * 4.0
    # Prefer a rate built from what Claude reports. Transcripts only hold what
    # happened on this machine, so a rate from them is blind to the phone and
    # the limit ETA it feeds promises room that is not there. The measured
    # figure stays as the fallback for a window too young to have moved yet.
    # The five-hour series restarts with its window, so for the first
    # three-quarters of an hour after a rollover it cannot say anything. The
    # weekly series measures the same spending against a different ceiling and
    # does not reset, so it covers that gap.
    from_pct = _burn_from_series(data, "session", out["session"]["limit"], now)
    burn_source = "reported percentage, 5-hour"
    if from_pct is None:
        from_pct = _burn_from_series(data, "week", out["week"]["limit"], now)
        burn_source = "reported percentage, weekly"
    if from_pct is not None:
        burn_hr = from_pct
    else:
        burn_source = "this machine only"
    fb_from_pct = _burn_from_series(data, "fable", out["fable"]["limit"], now)
    if fb_from_pct is not None:
        fb_burn = fb_from_pct

    etas = []
    for key in BUCKETS:
        b = out[key]
        remaining = b["limit"] * (100.0 - b["pct"]) / 100.0
        rate = fb_burn if key == "fable" else burn_hr
        cap = b["reset"] if b["reset"] > 0 else 1 << 30
        etas.append(_eta(remaining, rate, cap))
    live = [e for e in etas if e >= 0]
    eta = min(live) if live else -1

    waiting, waiting_what, waiting_kind = attention(now, _cfg_alert_done())
    cfg = load_config()
    worst = max(out[k]["pct"] for k in BUCKETS)

    # Pace is judged on the weekly window: five-hour windows reset too often
    # for "ahead of schedule" to mean anything useful.
    wk_start, wk_reset = win["week"]
    week_pace = pace(max(out["week"]["pct"], out["fable"]["pct"]),
                     wk_start, wk_reset, now)
    history, history_weekday = daily_history(events, now)
    idle_s = (now - events[-1][0]).total_seconds() if events else 1e9
    if any((now - t).total_seconds() < 3600 for t, _ in scanner.limit_hits):
        state = LIMITED
    elif worst >= 90:
        state = CRIT
    elif worst >= 75:
        state = WARN
    elif idle_s < 300:
        state = ACTIVE
    else:
        state = IDLE

    models, projects = defaultdict(float), defaultdict(float)
    for t, mod, proj, c in events:
        if t >= win["week"][0]:
            models[mod] += c
            projects[proj] += c

    return {
        "sess_pct": out["session"]["pct"], "sess_cost": out["session"]["cost"],
        "sess_limit": out["session"]["limit"], "sess_reset": out["session"]["reset"],
        "sess_limit_known": out["session"]["limit_known"],
        "wk_pct": out["week"]["pct"], "wk_cost": out["week"]["cost"],
        "wk_limit": out["week"]["limit"], "wk_reset": out["week"]["reset"],
        # The instant itself, not just the countdown. Six days of hours is a
        # number nobody can picture, so the weekly rows show a date instead.
        "wk_reset_at": win["week"][1],
        "wk_limit_known": out["week"]["limit_known"],
        "fb_pct": out["fable"]["pct"], "fb_cost": out["fable"]["cost"],
        "fb_limit": out["fable"]["limit"],
        "fb_limit_known": out["fable"]["limit_known"],
        "burn_hr": burn_hr, "burn_source": burn_source,
        "eta": eta, "state": state,
        "conf": conf, "calibrated": bool(data.get("calibrated_at")) and anchored_all,
        "live": live_all, "source": source,
        "attention": waiting, "attention_what": waiting_what,
        "attention_kind": waiting_kind,
        "pace": week_pace, "night": is_night(cfg, now), "config": cfg,
        "history": history, "history_weekday": history_weekday,
        # bit per bucket, so the panel can mark the ones it only estimated
        "live_mask": sum(1 << i for i, k in enumerate(BUCKETS)
                         if k in live or k in desk_anchor),
        # Always say what the endpoint is doing, even when the desktop cache
        # is answering. Hiding it behind "desktop sample 4 min old" is how a
        # 429 went unnoticed while the model-scoped bucket showed a figure
        # nobody had reported.
        "live_note": (("%s; desktop sample %.0f min old; %s"
                       % (source, desk["age_s"] / 60, live_usage.describe()))
                      if desk else "%s; %s" % (source, live_usage.describe())),
        "models": _top(models, 4, short_model), "projects": _top(projects, 3),
        "now": now,
    }
