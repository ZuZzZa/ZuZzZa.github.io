#!/usr/bin/env python3
"""The percentage-derived burn rate, which is what the limit ETA divides by.

Measuring spend from transcripts misses everything done elsewhere - the phone
app above all - so the rate is built from how the percentage Claude reports
moves instead. The parts worth pinning down are the ones already got wrong
once: a series that only records changes, and a five-hour window that resets
underneath it.

    python3 host/test_burn.py
"""
import datetime as dt
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import meter                                               # noqa: E402

failures = []


def check(cond, msg):
    if not cond:
        failures.append(msg)
    print("  %s %s" % ("ok  " if cond else "FAIL", msg))


def series(*points):
    """(minutes ago, percent) -> the stored shape."""
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    return {"buckets": {"k": {"series": [
        {"t": now - m * 60, "pct": p, "window": "W"} for m, p in points]}}}


def main():
    now = dt.datetime.now(dt.timezone.utc)

    print("a rate needs a long enough lever")
    d = series((20, 10.0), (0, 14.0))
    check(meter._burn_from_series(d, "k", 1000.0, now) is None,
          "20 minutes apart is refused - whole-number percentages need span")
    d = series((90, 10.0), (0, 14.0))
    rate = meter._burn_from_series(d, "k", 1000.0, now)
    check(rate is not None and abs(rate - 26.67) < 0.5,
          "90 minutes and 4 points of $1000 gives $%.2f/h" % (rate or 0))

    print("idleness has to show up as idleness")
    # The bug this replaced: recording only changes left the last point where
    # the percentage last moved, so an hour of doing nothing kept the old rate.
    d = series((180, 10.0), (120, 14.0), (60, 14.0), (0, 14.0))
    rate = meter._burn_from_series(d, "k", 1000.0, now)
    check(rate == 0.0,
          "no movement inside the window reads as zero, not as the old rate")

    print("samples are taken on a clock, not only on change")
    data = {"buckets": {}}
    t0 = now - dt.timedelta(minutes=30)
    meter._track(data, "k", 5.0, "W", t0)
    added = meter._track(data, "k", 5.0, "W", t0 + dt.timedelta(seconds=60))
    check(added is False, "a repeat a minute later is not worth recording")
    added = meter._track(data, "k", 5.0, "W",
                         t0 + dt.timedelta(seconds=meter.SAMPLE_GAP_S + 1))
    check(added is True,
          "but standing still for %d s is recorded, so idleness is visible"
          % meter.SAMPLE_GAP_S)

    print("a window that rolls takes its series with it")
    meter._track(data, "k", 3.0, "NEXT", now)
    kept = data["buckets"]["k"]["series"]
    check(len(kept) == 1 and kept[0]["window"] == "NEXT",
          "the old window's samples are dropped, not mixed into the new one")

    print("\n%s" % ("all checks passed" if not failures
                    else "FAILED: %d" % len(failures)))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
