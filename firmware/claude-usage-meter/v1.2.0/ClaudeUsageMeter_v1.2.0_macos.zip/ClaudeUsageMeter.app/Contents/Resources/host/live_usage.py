"""Reads the real utilisation figures from Claude's own usage endpoint.

Everything else in this project infers usage from local transcripts, which
cannot see chats outside Claude Code and cannot know the ceilings. This asks
the source instead - the same endpoint Settings -> Usage and `/usage` read:

    GET https://api.anthropic.com/api/oauth/usage

**Unofficial and undocumented.** It can change or vanish without notice, so
every failure here is soft: the caller keeps the local estimate rather than
showing nothing.

The access token is read fresh from the OS credential store on each refresh -
it expires periodically, so caching it would just produce 401s. It is never
logged, written to disk, or included in status.json.
"""
import datetime as dt
import glob
import json
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.request

ENDPOINT = "https://api.anthropic.com/api/oauth/usage"
KEYCHAIN_SERVICE = "Claude Code-credentials"
CRED_FILE = os.path.expanduser("~/.claude/.credentials.json")

# Polling harder than this earns persistent 429s, and the numbers move slowly -
# a percentage that shifts a point every few minutes does not need a sample
# every 45 seconds, which is what this used to be.
MIN_INTERVAL = 120.0
BACKOFF_MAX = 900.0
DEFAULT_UA_VERSION = "2.1.237"

token_source = ""       # which credential _read_token last used, for the log
_cache = {"data": None, "fetched": 0.0, "next_try": 0.0, "backoff": 0.0,
          "error": None, "keys": None}


def _claude_code_version():
    """Match the local Claude Code build - a plausible User-Agent is part of
    what keeps this endpoint from rate-limiting the request."""
    # Read from a transcript rather than asking the CLI: `claude --version`
    # can take ten seconds to answer, and this runs on every refresh inside a
    # daemon that must not block. The transcript value is a real build string.
    newest, version = 0, DEFAULT_UA_VERSION
    for path in glob.glob(os.path.expanduser("~/.claude/projects/*/*.jsonl")):
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            continue
        if mtime <= newest:
            continue
        try:
            with open(path, errors="ignore") as fh:
                for line in fh:
                    v = json.loads(line).get("version")
                    if v:
                        newest, version = mtime, v
                        break
        except (OSError, ValueError):
            continue
    return version


def _note_source(where):
    global token_source
    token_source = where


def _token_expiry():
    """When the stored credential runs out, as a unix timestamp, or None.

    Only the expiry is read - never the token itself, which stays in the
    keychain until the moment a request needs it.
    """
    try:
        if os.path.isfile(CRED_FILE):
            with open(CRED_FILE) as fh:
                blob = json.load(fh)
        else:
            out = subprocess.run(
                ["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
                capture_output=True, text=True, timeout=15)
            if out.returncode:
                return None
            blob = json.loads(out.stdout)
        at = blob.get("claudeAiOauth", {}).get("expiresAt")
        return (at / 1000.0 if at and at > 1e11 else at) or None
    except (OSError, ValueError, KeyError, subprocess.SubprocessError):
        return None


def _read_token():
    """The signed-in credential first; CLAUDE_CODE_OAUTH_TOKEN as a fallback.

    That order is the wrong way round for most tools and right for this one.
    `claude setup-token` mints a token that lasts a year instead of eight
    hours, which sounds like the better credential until you try it here: it
    is scoped to inference, this endpoint is account data, and it answers 403.
    The signed-in credential carries user:profile as well, so it is the one
    that works. Preferring the environment variable would let a well-meant
    long-lived token silently shadow the only credential that can do the job.

    It stays as a fallback for machines with no keychain to read - CI, a
    container - where inference scope may be all that is wanted anyway.
    """
    if os.path.isfile(CRED_FILE):
        try:
            with open(CRED_FILE) as fh:
                tok = json.load(fh)["claudeAiOauth"]["accessToken"]
            if tok:
                _note_source("the credentials file")
                return tok
        except (OSError, ValueError, KeyError):
            pass
    try:
        out = subprocess.run(
            ["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
            capture_output=True, text=True, timeout=15)
        if out.returncode == 0:
            tok = json.loads(out.stdout)["claudeAiOauth"]["accessToken"]
            if tok:
                _note_source("the signed-in credential")
                return tok
    except (OSError, subprocess.SubprocessError, ValueError, KeyError):
        pass
    env = os.environ.get("CLAUDE_CODE_OAUTH_TOKEN", "").strip()
    _note_source("CLAUDE_CODE_OAUTH_TOKEN" if env else "")
    return env or None


def _request(token):
    req = urllib.request.Request(ENDPOINT, headers={
        "Authorization": "Bearer " + token,
        "anthropic-beta": "oauth-2025-04-20",
        "User-Agent": "claude-code/" + _claude_code_version(),
        "Accept": "application/json",
    })
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch(force=False):
    """-> (data|None, error|None). Cached; safe to call every cycle."""
    now = time.monotonic()
    if not force:
        if (_cache["data"] is not None and now - _cache["fetched"] < MIN_INTERVAL
                and not _window_passed(_cache["data"])):
            return _cache["data"], None
        if now < _cache["next_try"]:
            return _cache["data"], _cache["error"]

    token = _read_token()
    if not token:
        _cache["error"] = "no OAuth token (is Claude Code signed in?)"
        _cache["next_try"] = now + 300
        return _cache["data"], _cache["error"]

    try:
        data = _request(token)
    except urllib.error.HTTPError as exc:
        reason = "HTTP %d" % exc.code
        wait = min(BACKOFF_MAX, max(120.0, (_cache["backoff"] or 60.0) * 2))
        if exc.code == 401:
            # The credential lasts about eight hours and is only renewed when
            # the CLI itself talks to the API - signing in and then never
            # running it again leaves this expiring quietly overnight. Say so,
            # because "HTTP 401" sends people looking in the wrong place.
            exp = _token_expiry()
            if exp and exp < time.time():
                mins = (time.time() - exp) / 60.0
                reason = ("credential expired %.0f min ago - run "
                          "`claude setup-token` for one that lasts, or "
                          "`claude auth login` again" % mins)
                wait = 900.0
            else:
                reason = "HTTP 401 (credential rejected)"
                wait = 60.0
        _cache["backoff"] = 0.0 if wait <= 60.0 else wait
        _cache["next_try"] = now + wait
        _cache["error"] = reason
        return _cache["data"], _cache["error"]
    except Exception as exc:                       # offline, DNS, timeout
        _cache["next_try"] = now + 120
        _cache["error"] = str(exc)[:80]
        return _cache["data"], _cache["error"]

    _cache.update(data=data, fetched=now, next_try=0.0, backoff=0.0, error=None)
    if _cache["keys"] != sorted(data):
        _cache["keys"] = sorted(data)
    return data, None


def _window_passed(data, kind="session"):
    """Has the window this payload describes already ended?

    The five-hour window rolls, and for the two minutes the payload stays
    cached afterwards it still names the old instant - an instant now in the
    past. Downstream that is worse than having nothing: a reset time that has
    been and gone gets rolled forward by guesswork against local transcripts,
    which produces a countdown to a boundary Claude knows nothing about. The
    panel showed 23 minutes to a window that had already turned over.
    """
    for row in (data or {}).get("limits") or []:
        if isinstance(row, dict) and row.get("kind") == kind:
            at = row.get("resets_at")
            if not at:
                return False
            try:
                when = dt.datetime.fromisoformat(str(at).replace("Z", "+00:00"))
            except ValueError:
                return False
            return when <= dt.datetime.now(dt.timezone.utc)
    return False


def buckets(data):
    """Map the payload onto our three buckets.

    The payload carries a `limits` array that states each window outright -
    kind, percent, reset instant, and for the model-scoped weekly one the
    model it applies to. Read that first. It is the only place the scoped
    weekly bucket appears at all on this account: the top-level
    `seven_day_opus` is null and there is no `seven_day_fable`, so the older
    name-matching path found nothing and the panel showed a local guess.

    The rest of the payload is undocumented and carries codenames that come
    and go, so everything here matches on shape and treats absence as normal.
    """
    if not isinstance(data, dict):
        return {}

    out = {}
    for row in data.get("limits") or []:
        if not isinstance(row, dict):
            continue
        pct, at = row.get("percent"), row.get("resets_at")
        if pct is None:
            continue
        key = {"session": "session", "weekly_all": "week",
               "weekly_scoped": "fable"}.get(row.get("kind"))
        if not key:
            continue
        out[key] = {"utilization": float(pct), "resets_at": at}

    def pick(*names):
        for n in names:
            v = data.get(n)
            if isinstance(v, dict) and v.get("utilization") is not None:
                return v
        return None

    # Older shape, still the fallback: separate top-level keys.
    for key, val in (("session", pick("five_hour")), ("week", pick("seven_day"))):
        if key not in out and val:
            out[key] = val
    if "fable" not in out:
        model_weekly = pick("seven_day_fable", "seven_day_opus")
        if model_weekly is None:
            for key, val in data.items():
                if (key.startswith("seven_day") and key != "seven_day"
                        and isinstance(val, dict)
                        and val.get("utilization") is not None):
                    model_weekly = val
                    break
        if model_weekly:
            out["fable"] = model_weekly

    return out


def scoped_model_name(data):
    """What the account's model-scoped weekly limit is actually called.

    The panel's label for that row is baked into the firmware, so this is how
    we find out when the two have drifted apart. Kept out of buckets() on
    purpose: everything that comes back from there is treated as a bucket.
    """
    if not isinstance(data, dict):
        return None
    for row in data.get("limits") or []:
        if isinstance(row, dict) and row.get("kind") == "weekly_scoped":
            scope = row.get("scope")
            model = (scope or {}).get("model") if isinstance(scope, dict) else None
            if isinstance(model, dict):
                return model.get("display_name")
    return None


def describe():
    """One line for the log and the menu. Genuinely one line.

    It used to append every field name the payload carried, which is a dozen
    codenames and belongs in check_live.py, not in a status line someone reads
    at a glance.
    """
    if _cache["data"] is None:
        return "live usage unavailable (%s)" % (_cache["error"] or "not tried yet")
    age = time.monotonic() - _cache["fetched"]
    return "live usage ok, %.0fs old, via %s" % (age, token_source or "unknown")
