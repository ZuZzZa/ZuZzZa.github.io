#!/usr/bin/env python3
"""Check the firmware's clock guard against real corruption.

The function is lifted out of src/main.cpp and compiled, rather than
reimplemented here - a reimplementation would only prove that two copies of
my own reasoning agree.

The bad strings are not invented. They are what the panel actually displayed
when a byte went missing on the wire and the gauge frame ran onto the end of
the clock frame: "T|16:45" losing its newline and meeting "G|93|1990|..."
leaves the clock field holding "16:4G".
"""
import re, subprocess, sys, tempfile, os

SRC = os.path.join(os.path.dirname(__file__), "..", "src", "main.cpp")

CORRUPT = ["G", "16G", "16:4G", "", "1", "16:4", "16:456", "1:45",
           "24:00", "16:60", "ab:cd", "16;45", "16:4 "]
GOOD = ["00:00", "16:45", "23:59", "09:05"]


def extract(name):
    text = open(SRC).read()
    m = re.search(r"^static bool %s\(const char \*s\) \{.*?^\}" % name,
                  text, re.S | re.M)
    if not m:
        raise SystemExit("could not find %s() in src/main.cpp" % name)
    return m.group(0)


def main():
    body = extract("validClock")
    harness = """
#include <stdio.h>
#include <stdint.h>
typedef unsigned char uint8_t_;
%s
int main(int argc, char **argv) {
    for (int i = 1; i < argc; i++)
        printf("%%d\\n", validClock(argv[i]) ? 1 : 0);
    return 0;
}
""" % body
    with tempfile.TemporaryDirectory() as d:
        src, exe = os.path.join(d, "t.cpp"), os.path.join(d, "t")
        open(src, "w").write(harness)
        r = subprocess.run(["c++", "-std=c++11", "-O0", "-o", exe, src],
                           capture_output=True, text=True)
        if r.returncode:
            raise SystemExit("compile failed:\n" + r.stderr)
        args = CORRUPT + GOOD
        out = subprocess.run([exe] + args, capture_output=True,
                             text=True).stdout.split()

    bad = []
    for arg, got in zip(args, out):
        want = arg in GOOD
        if (got == "1") != want:
            bad.append("%r accepted=%s, expected=%s" % (arg, got == "1", want))
    for line in bad:
        print("FAIL:", line)
    if bad:
        return 1
    print("ok: clock guard rejects all %d corrupt forms, accepts all %d valid"
          % (len(CORRUPT), len(GOOD)))
    print("    including the three seen on the panel: 'G', '16G', '16:4G'")
    return 0


if __name__ == "__main__":
    sys.exit(main())
