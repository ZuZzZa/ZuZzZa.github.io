#!/usr/bin/env python3
"""Checks whether the live usage endpoint works on this machine.

Reading the OS credential store is something to authorise deliberately, so
this is a separate script rather than something the daemon does silently on
first run. macOS asks for permission the first time; choosing "Always Allow"
stops it asking again.

    python3 host/check_live.py

It prints which buckets the endpoint returned. About the token it prints only
the length, and it stores nothing.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import live_usage                                          # noqa: E402


def main():
    token = live_usage._read_token()
    if not token:
        print("No token found.")
        print("  file fallback: %s" % live_usage.CRED_FILE)
        print("Is Claude Code signed in on this machine?")
        return 1

    print("token found: %d characters from %s (not shown, not stored)"
          % (len(token), live_usage.token_source or "an unknown source"))
    print("user-agent:  claude-code/%s" % live_usage._claude_code_version())

    data, err = live_usage.fetch(force=True)
    if err or not data:
        print("endpoint failed: %s" % (err or "empty response"))
        return 1

    print()
    print("fields returned: %s" % ", ".join(sorted(data)))
    found = live_usage.buckets(data)
    if not found:
        print("None of them looked like a utilisation bucket, so the payload")
        print("shape has changed. Raw response:")
        print(data)
        return 1

    print()
    for key, label in (("session", "5-hour"), ("week", "week all"),
                       ("fable", "week model")):
        bucket = found.get(key)
        if bucket:
            print("  %-11s %5.1f%%   resets %s"
                  % (label, bucket["utilization"], bucket.get("resets_at", "?")))
        else:
            print("  %-11s not reported - falls back to the local estimate" % label)
    return 0


if __name__ == "__main__":
    sys.exit(main())
