#!/usr/bin/env python3
"""Records when Claude Code is waiting on you, for the panel to blink about.

Wired to Claude Code hooks in ~/.claude/settings.json:

    set   <- Notification, PermissionRequest
    clear <- UserPromptSubmit, PostToolUse

`Notification` is Claude Code's own "needs the user" signal and covers both
idle-waiting and permission prompts; `PermissionRequest` fires right before a
permission dialog, which is the case worth blinking about. Clearing on
`PostToolUse` is what makes a granted permission stop the blink - the tool
having run is proof the dialog was answered.

Hooks receive their payload as JSON on stdin. This reads it opportunistically:
a hook that dies on malformed input would take the turn down with it, so
every failure here is swallowed.

    python3 attention_hook.py set|clear
"""
import json
import os
import sys
import time

STATE_DIR = os.path.expanduser("~/.claude-usage-meter")
MARKER = os.path.join(STATE_DIR, "attention.json")


def read_payload():
    if sys.stdin.isatty():
        return {}
    try:
        raw = sys.stdin.read()
    except Exception:
        return {}
    try:
        return json.loads(raw) if raw.strip() else {}
    except ValueError:
        return {}


def summarise(payload):
    """A short label for the log; the panel only needs the fact, not the text."""
    for key in ("message", "notification", "reason"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()[:120]
    tool = payload.get("tool_name")
    return ("permission: " + tool) if tool else "input needed"


def main():
    action = sys.argv[1] if len(sys.argv) > 1 else "set"
    payload = read_payload()
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        if action == "clear":
            if os.path.exists(MARKER):
                os.remove(MARKER)
        else:
            tmp = MARKER + ".tmp"
            with open(tmp, "w") as fh:
                json.dump({"at": time.time(),
                           "what": summarise(payload),
                           "session": payload.get("session_id", "")}, fh)
            os.replace(tmp, MARKER)
    except OSError:
        pass          # never let a blinking light break a Claude Code turn
    return 0


if __name__ == "__main__":
    sys.exit(main())
