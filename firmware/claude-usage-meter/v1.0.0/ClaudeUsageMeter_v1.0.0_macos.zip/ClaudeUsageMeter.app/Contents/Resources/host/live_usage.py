"""Reads the real utilisation figures from Claude's own usage endpoint.

Everything else in this project infers usage from local transcripts, which
cannot see chats outside Claude Code and cannot know the ceilings. This asks
the source instead - the same endpoint Settings -> Usage and `/usage` read:

    GET https://api.anthropic.com/api/oauth/usage

**Unofficial and undocumented.** It can change or vanish without notice, so
every failure here is soft: the caller keeps the local estimate rather than
showing nothing.

The access token is read fresh from the OS credential store on each refresh -
it expires periodically, so caching it would just produce 401s. It is never
logged, written to disk, or included in status.json.
"""
import glob
import json
import os
import subprocess
import time
import urllib.error
import urllib.request

ENDPOINT = "https://api.anthropic.com/api/oauth/usage"
KEYCHAIN_SERVICE = "Claude Code-credentials"
CRED_FILE = os.path.expanduser("~/.claude/.credentials.json")

# Polling harder than this earns persistent 429s, and the numbers move slowly.
MIN_INTERVAL = 45.0
BACKOFF_MAX = 900.0
DEFAULT_UA_VERSION = "2.1.237"

_cache = {"data": None, "fetched": 0.0, "next_try": 0.0, "backoff": 0.0,
          "error": None, "keys": None}


def _claude_code_version():
    """Match the local Claude Code build - a plausible User-Agent is part of
    what keeps this endpoint from rate-limiting the request."""
    newest, version = 0, DEFAULT_UA_VERSION
    for path in glob.glob(os.path.expanduser("~/.claude/projects/*/*.jsonl")):
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            continue
        if mtime <= newest:
            continue
        try:
            with open(path, errors="ignore") as fh:
                for line in fh:
                    v = json.loads(line).get("version")
                    if v:
                        newest, version = mtime, v
                        break
        except (OSError, ValueError):
            continue
    return version


def _read_token():
    """macOS keeps it in the keychain; other platforms in a dotfile."""
    if os.path.isfile(CRED_FILE):
        try:
            with open(CRED_FILE) as fh:
                return json.load(fh)["claudeAiOauth"]["accessToken"]
        except (OSError, ValueError, KeyError):
            pass
    try:
        out = subprocess.run(
            ["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
            capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    try:
        return json.loads(out.stdout)["claudeAiOauth"]["accessToken"]
    except (ValueError, KeyError):
        return None


def _request(token):
    req = urllib.request.Request(ENDPOINT, headers={
        "Authorization": "Bearer " + token,
        "anthropic-beta": "oauth-2025-04-20",
        "User-Agent": "claude-code/" + _claude_code_version(),
        "Accept": "application/json",
    })
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch(force=False):
    """-> (data|None, error|None). Cached; safe to call every cycle."""
    now = time.monotonic()
    if not force:
        if _cache["data"] is not None and now - _cache["fetched"] < MIN_INTERVAL:
            return _cache["data"], None
        if now < _cache["next_try"]:
            return _cache["data"], _cache["error"]

    token = _read_token()
    if not token:
        _cache["error"] = "no OAuth token (is Claude Code signed in?)"
        _cache["next_try"] = now + 300
        return _cache["data"], _cache["error"]

    try:
        data = _request(token)
    except urllib.error.HTTPError as exc:
        # 401 means the token rotated; the next cycle reads a fresh one.
        wait = 60.0 if exc.code == 401 else min(
            BACKOFF_MAX, max(120.0, (_cache["backoff"] or 60.0) * 2))
        _cache["backoff"] = 0.0 if exc.code == 401 else wait
        _cache["next_try"] = now + wait
        _cache["error"] = "HTTP %d" % exc.code
        return _cache["data"], _cache["error"]
    except Exception as exc:                       # offline, DNS, timeout
        _cache["next_try"] = now + 120
        _cache["error"] = str(exc)[:80]
        return _cache["data"], _cache["error"]

    _cache.update(data=data, fetched=now, next_try=0.0, backoff=0.0, error=None)
    if _cache["keys"] != sorted(data):
        _cache["keys"] = sorted(data)
    return data, None


def buckets(data):
    """Map the payload onto our three buckets.

    Field names are not documented, so match by shape rather than assuming:
    anything with a `utilization` is a bucket, and the weekly model-specific
    one has been seen as `seven_day_opus` while the UI calls it by the current
    top model's name.
    """
    if not isinstance(data, dict):
        return {}

    def pick(*names):
        for n in names:
            v = data.get(n)
            if isinstance(v, dict) and v.get("utilization") is not None:
                return v
        return None

    model_weekly = pick("seven_day_fable", "seven_day_opus")
    if model_weekly is None:
        for key, val in data.items():
            if (key.startswith("seven_day") and key != "seven_day"
                    and isinstance(val, dict) and val.get("utilization") is not None):
                model_weekly = val
                break

    return {k: v for k, v in (("session", pick("five_hour")),
                              ("week", pick("seven_day")),
                              ("fable", model_weekly)) if v}


def describe():
    """One line for the log/menu about where the numbers came from."""
    if _cache["data"] is None:
        return "live usage unavailable (%s)" % (_cache["error"] or "not tried yet")
    age = time.monotonic() - _cache["fetched"]
    return "live usage ok, %.0fs old, fields: %s" % (age, ", ".join(_cache["keys"] or []))
