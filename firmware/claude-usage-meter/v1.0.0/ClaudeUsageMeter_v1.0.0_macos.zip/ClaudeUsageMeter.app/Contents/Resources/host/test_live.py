#!/usr/bin/env python3
"""Exercises the live-usage path with a stubbed endpoint.

No credential store is touched and no network call is made: the reader and the
request are both replaced. State is redirected to a temporary directory - an
earlier version of this test wrote stub reset times into the real calibration
file and made the panel read 3.5%.

    python3 host/test_live.py
"""
import json
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import desktop_usage                                       # noqa: E402
import live_usage                                          # noqa: E402
import meter                                               # noqa: E402
from usage import Scanner                                  # noqa: E402

STUB = {
    "five_hour":      {"utilization": 21.0, "resets_at": "2026-08-22T19:32:00+00:00"},
    "seven_day":      {"utilization": 46.0, "resets_at": "2026-08-23T09:05:00+00:00"},
    "seven_day_opus": {"utilization": 78.0, "resets_at": "2026-08-23T09:05:00+00:00"},
    "extra_usage":    {"ignored": True},
}

failures = []


def check(cond, msg):
    if not cond:
        failures.append(msg)
    print("  %s %s" % ("ok  " if cond else "FAIL", msg))


def silence_desktop():
    """The desktop cache is a second source; mute it to test the others alone."""
    desktop_usage.latest = lambda now=None: None


def stub_desktop():
    """A synthetic cache reading, so the test does not depend on this machine
    having Claude Desktop installed - CI runs it on Linux."""
    import datetime as dt
    desktop_usage.latest = lambda now=None: {
        "session": 21.0, "week": 46.0, "fresh": True, "age_s": 120.0,
        "at": (now or dt.datetime.now(dt.timezone.utc)) - dt.timedelta(minutes=2),
    }


def reset_cache():
    live_usage._cache.update(data=None, fetched=0.0, next_try=0.0,
                             backoff=0.0, error=None)


def main():
    sandbox = tempfile.mkdtemp(prefix="cum-test-")
    meter.STATE_DIR = sandbox
    meter.CALIB_PATH = os.path.join(sandbox, "calib.json")

    scanner = Scanner()
    scanner.poll()
    real_latest = desktop_usage.latest

    try:
        print("bucket mapping")
        mapped = live_usage.buckets(STUB)
        check(set(mapped) == {"session", "week", "fable"},
              "all three buckets recognised, extra_usage ignored")
        check(mapped["fable"]["utilization"] == 78.0,
              "the model-specific weekly bucket maps to fable")

        print("endpoint reachable")
        live_usage._read_token = lambda: "stub"
        live_usage._request = lambda token: STUB
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["live"] is True and s["conf"] == meter.CONF_LIVE,
              "reported as live, confidence %d" % s["conf"])
        check(abs(s["sess_pct"] - 21.0) < 0.01
              and abs(s["wk_pct"] - 46.0) < 0.01
              and abs(s["fb_pct"] - 78.0) < 0.01,
              "percentages come straight from the endpoint")
        check(s["sess_reset"] > 0 and s["wk_reset"] > 0,
              "reset countdowns adopted from the payload")

        print("endpoint unavailable, desktop cache present")
        live_usage._read_token = lambda: None
        stub_desktop()
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["source"] == "desktop cache",
              "falls through to the desktop cache, not to guesswork")

        print("neither source available")
        silence_desktop()
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["live"] is False, "falls back instead of failing")
        check(s["sess_pct"] >= 0, "still produces a figure (%.1f%%)" % s["sess_pct"])

        print("endpoint erroring, no desktop cache either")
        live_usage._read_token = lambda: "stub"

        def explode(token):
            raise RuntimeError("simulated 429")

        live_usage._request = explode
        reset_cache()
        s = meter.snapshot(scanner)
        check(s["live"] is False, "an error is soft, not fatal")
        check("429" in s["live_note"], "the reason is reported: %s" % s["live_note"])

        print("state isolation")
        real = os.path.expanduser("~/.claude-usage-meter/calib.json")
        if os.path.exists(real):
            with open(real) as fh:
                live_reset = json.load(fh).get("session_reset")
            check(live_reset != STUB["five_hour"]["resets_at"],
                  "the real calibration file was left alone")
        else:
            check(True, "no real calibration file on this machine, nothing to disturb")
    finally:
        desktop_usage.latest = real_latest
        shutil.rmtree(sandbox, ignore_errors=True)

    print()
    if failures:
        print("FAILED: %d" % len(failures))
        return 1
    print("all checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
