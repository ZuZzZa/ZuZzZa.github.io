"""Turns raw usage events into the numbers shown on the panel.

Anthropic does not expose limits locally, and the transcripts under
~/.claude/projects only cover Claude Code - regular Claude chats on the web,
in the desktop app or on a phone eat the same allowance and leave nothing
here to read. So the local measurement is a *lower bound* on real usage, and
no formula over it can reproduce the reported percentage.

What works instead is anchoring. Each calibration records the reported
percentage together with what we could see at that moment; between
calibrations we add only the change we can observe:

    pct = pct_at_anchor + (visible_now - visible_at_anchor) / limit * 100

That is exact for work done through Claude Code and silently low for anything
done elsewhere, which is the honest failure mode - it under-reports rather
than inventing headroom.

`limit` itself comes from two readings in the same window:

    limit = change_in_visible / change_in_percent

The UI reports whole percents, so a change of one or two points is mostly
rounding noise; a refit is only accepted past MIN_FIT_POINTS. Fitting the
5-hour ceiling this way gave $661 where a single-reading estimate had said
$310 - the error a proportional model was quietly carrying.
"""
import os
import json
import time
import datetime as dt
from collections import defaultdict

import desktop_usage
import live_usage
from usage import five_hour_blocks, short_model, BLOCK_HOURS, WEEK_DAYS

STATE_DIR = os.path.expanduser("~/.claude-usage-meter")
CALIB_PATH = os.path.join(STATE_DIR, "calib.json")
ATTENTION_PATH = os.path.join(STATE_DIR, "attention.json")
ATTENTION_MAX_AGE = 3600     # a marker this old outlived whatever set it

SEEDS = {"session": 300.0, "week": 1500.0, "fable": 500.0}
MIN_FIT_POINTS = 3        # percent points of movement before a refit is trusted
FRESH_HOURS = 6           # an anchor older than this stops claiming high confidence

IDLE, ACTIVE, WARN, CRIT, LIMITED = 0, 1, 2, 3, 4
CONF_LOCAL_MAX = 3
CONF_LIVE = 4             # reported by Claude itself, not inferred
BUCKETS = ("session", "week", "fable")
LABELS = {"session": "5-hour", "week": "Week all", "fable": "Week Fable"}


def is_fable(model):
    return "fable" in (model or "")


def attention(now=None):
    """-> (waiting, what). Written by attention_hook.py from Claude Code hooks.

    The marker is removed when you answer, so its mere presence is the signal.
    An age cap covers the case where the clearing hook never ran - a crashed
    session should not leave the panel blinking forever.
    """
    try:
        with open(ATTENTION_PATH) as fh:
            doc = json.load(fh)
    except (OSError, ValueError):
        return False, ""
    at = doc.get("at")
    if not isinstance(at, (int, float)):
        return False, ""
    if time.time() - at > ATTENTION_MAX_AGE:
        return False, ""
    return True, str(doc.get("what", ""))[:120]


def load_calib():
    try:
        with open(CALIB_PATH) as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        data = {}
    data.setdefault("buckets", {})
    data.setdefault("readings", [])
    for key in BUCKETS:
        data["buckets"].setdefault(key, {})
    return data


def save_calib(data):
    os.makedirs(STATE_DIR, exist_ok=True)
    tmp = CALIB_PATH + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
    os.replace(tmp, CALIB_PATH)


def _iso(t):
    return t.astimezone(dt.timezone.utc).isoformat()


def _parse(s):
    try:
        return dt.datetime.fromisoformat(s) if s else None
    except (TypeError, ValueError):
        return None


def same_window(a, b, tol_min=20):
    """Window identity, compared with slack.

    A window is keyed by its reset instant, but the usage screen reports the
    time remaining rounded to whole minutes, so two readings of the *same*
    window land a few minutes apart. Exact matching would silently treat every
    reading as a fresh window and never fit a ceiling.
    """
    ta, tb = _parse(a), _parse(b)
    if ta is None or tb is None:
        return bool(a) and a == b
    return abs((ta - tb).total_seconds()) <= tol_min * 60


def visible_cost(events, lo, hi=None, only_fable=False):
    return sum(c for t, m, _, c in events
               if t >= lo and (hi is None or t < hi)
               and (not only_fable or is_fable(m)))


# ---------------------------------------------------------------- windows

def _roll_session(reset, events, now):
    """Advance a stale session anchor: a new window opens on the next request."""
    while reset is not None and reset <= now:
        nxt = next((t for t, _, _, _ in events if t >= reset), None)
        if nxt is None:
            return None
        reset = nxt + dt.timedelta(hours=BLOCK_HOURS)
    return reset


def windows(data, events, now):
    """-> {bucket: (start, reset_or_None)} for the live windows."""
    sess_reset = _roll_session(_parse(data.get("session_reset")), events, now)
    if sess_reset:
        sess_start = sess_reset - dt.timedelta(hours=BLOCK_HOURS)
    else:
        blocks = five_hour_blocks(events)
        cur = blocks[-1] if blocks and blocks[-1]["end"] > now else None
        sess_start = cur["start"] if cur else now
        sess_reset = cur["end"] if cur else None

    wk_reset = _parse(data.get("week_reset"))
    while wk_reset is not None and wk_reset <= now:
        wk_reset += dt.timedelta(days=WEEK_DAYS)
    wk_start = (wk_reset - dt.timedelta(days=WEEK_DAYS)) if wk_reset \
        else now - dt.timedelta(days=WEEK_DAYS)

    return {"session": (sess_start, sess_reset),
            "week": (wk_start, wk_reset),
            "fable": (wk_start, wk_reset)}


def measure(events, win):
    return {"session": visible_cost(events, win["session"][0]),
            "week": visible_cost(events, win["week"][0]),
            "fable": visible_cost(events, win["fable"][0], only_fable=True)}


# ---------------------------------------------------------------- calibration

def calibrate(events, session, week, fable, now=None):
    """Records one reading of the Claude usage screen and refits what it can.

    `session` and `week` are (percent, minutes-to-reset); `fable` is a percent
    and shares the weekly reset.
    """
    now = now or dt.datetime.now(dt.timezone.utc)
    data = load_calib()

    if session and session[1]:
        data["session_reset"] = _iso(now + dt.timedelta(minutes=session[1]))
    if week and week[1]:
        data["week_reset"] = _iso(now + dt.timedelta(minutes=week[1]))

    win = windows(data, events, now)
    seen = measure(events, win)
    reported = {"session": session[0] if session else None,
                "week": week[0] if week else None,
                "fable": fable if fable is not None else None}

    report = {}
    for key in BUCKETS:
        pct = reported[key]
        if pct is None:
            continue
        entry = data["buckets"][key]
        window_id = _iso(win[key][1]) if win[key][1] else ""
        prior = entry.get("anchor")

        fitted = None
        if prior and same_window(prior.get("window"), window_id):
            d_pct = pct - prior["pct"]
            d_vis = seen[key] - prior["visible"]
            if d_pct >= MIN_FIT_POINTS and d_vis > 0:
                fitted = d_vis / (d_pct / 100.0)
                entry["limit"] = round(fitted, 2)
                entry["limit_from"] = "two readings %.0f%% apart" % d_pct

        entry.setdefault("limit", SEEDS[key])
        entry["anchor"] = {"t": _iso(now), "visible": round(seen[key], 2),
                           "pct": float(pct), "window": window_id}
        report[key] = {"visible": seen[key], "pct": pct,
                       "limit": entry["limit"], "fitted": fitted}

    data["readings"].append(
        {"t": _iso(now),
         **{k: {"visible": round(seen[k], 2), "pct": reported[k]}
            for k in BUCKETS if reported[k] is not None}})
    data["readings"] = data["readings"][-50:]
    data["calibrated_at"] = _iso(now)
    save_calib(data)
    return report


# ---------------------------------------------------------------- snapshot

def _top(mapping, n, namer=lambda x: x):
    total = sum(mapping.values()) or 1.0
    rows = sorted(mapping.items(), key=lambda kv: -kv[1])[:n]
    return [(namer(k), int(round(100.0 * v / total)), v) for k, v in rows if v > 0]


def _eta(remaining, burn_hr, cap_min):
    if burn_hr <= 0.01 or remaining <= 0:
        return 0 if remaining <= 0 else -1
    mins = int(remaining / burn_hr * 60)
    return mins if mins < cap_min else -1


def _apply_live_resets(data, live):
    """The endpoint reports the real reset instants; adopt them so the local
    cost windows line up with the buckets the percentages describe."""
    changed = False
    for key, field in (("session", "session_reset"), ("week", "week_reset")):
        at = live.get(key, {}).get("resets_at")
        if not at:
            continue
        parsed = _parse(at)
        if parsed is None:
            continue
        prior = _parse(data.get(field))
        if prior is None or abs((parsed - prior).total_seconds()) > 120:
            data[field] = _iso(parsed)
            changed = True
    return changed


def _auto_fit(data, key, pct, visible, window_id):
    """Two live readings in one window give the ceiling for free.

    The percentages arrive continuously now, so the dollar ceilings no longer
    need a human reading them off a screen - they converge on their own.
    """
    entry = data["buckets"].setdefault(key, {})
    auto = entry.get("auto")
    if auto and same_window(auto.get("window"), window_id):
        d_pct = pct - auto["pct"]
        d_vis = visible - auto["visible"]
        if d_pct >= MIN_FIT_POINTS and d_vis > 0:
            fitted = d_vis / (d_pct / 100.0)
            prior = entry.get("limit") or 0
            entry["limit"] = round(fitted, 2)
            entry["limit_from"] = "live readings %.0f%% apart" % d_pct
            entry["auto"] = {"pct": pct, "visible": visible, "window": window_id}
            return abs(fitted - prior) > max(1.0, prior * 0.02)
        return False
    entry["auto"] = {"pct": pct, "visible": visible, "window": window_id}
    return True


def snapshot(scanner, now=None):
    now = now or dt.datetime.now(dt.timezone.utc)
    events = scanner.events
    data = load_calib()

    # Source order: the OAuth endpoint if it answers (instant, all three
    # buckets), otherwise the figures Claude Desktop already caches on disk
    # (two buckets, up to 15 minutes stale, no credentials involved).
    live_raw, live_err = live_usage.fetch()
    live = live_usage.buckets(live_raw) if live_raw else {}
    dirty = _apply_live_resets(data, live) if live else False

    win = windows(data, events, now)
    seen = measure(events, win)

    desk = desktop_usage.latest(now)
    source = "endpoint" if live else ("desktop cache" if desk and desk["fresh"]
                                      else "local estimate")
    desk_anchor = {}
    if desk and desk["fresh"]:
        for key, field, only_fable in (("session", "session", False),
                                       ("week", "week", False)):
            pct = desk.get(field)
            if pct is None or key in live:
                continue
            start = win[key][0]
            fit = desktop_usage.fit_ceiling(
                events, since=start, now=now,
                field="fh" if key == "session" else "sd", only_fable=only_fable)
            entry = data["buckets"].setdefault(key, {})
            if fit:
                ceiling, span, r = fit
                if r >= 0.9 and abs(ceiling - (entry.get("limit") or 0)) > 1.0:
                    entry["limit"] = round(ceiling, 2)
                    entry["limit_from"] = ("desktop history, %.0f points, r=%.3f"
                                           % (span, r))
                    dirty = True
            desk_anchor[key] = {
                "pct": float(pct),
                "visible": visible_cost(events, start, desk["at"]),
            }

    anchored_all, oldest_anchor = True, None
    # Fable is never in the desktop cache, so requiring all three would mean
    # never reporting the source that is actually authoritative for two.
    live_keys = set(live) | set(desk_anchor)
    live_all = {"session", "week"}.issubset(live_keys)
    out = {}
    for key in BUCKETS:
        entry = data["buckets"].get(key, {})
        limit = entry.get("limit") or SEEDS[key]
        anchor = entry.get("anchor")
        window_id = _iso(win[key][1]) if win[key][1] else ""

        if key in live:
            pct = float(live[key]["utilization"])
            if _auto_fit(data, key, pct, seen[key], window_id):
                dirty = True
            limit = data["buckets"][key].get("limit") or limit
        elif key in desk_anchor:
            # Anchored to Claude's own sample, extrapolated with measured spend
            # for the minutes since it was taken.
            limit = data["buckets"][key].get("limit") or limit
            a = desk_anchor[key]
            pct = a["pct"] + (seen[key] - a["visible"]) / limit * 100.0
        elif anchor and same_window(anchor.get("window"), window_id):
            pct = anchor["pct"] + (seen[key] - anchor["visible"]) / limit * 100.0
            at = _parse(anchor["t"])
            if at and (oldest_anchor is None or at < oldest_anchor):
                oldest_anchor = at
        else:
            # Fresh window: the hidden share of it is unknown, so this is the
            # visible floor rather than a reading.
            pct = seen[key] / limit * 100.0 if limit else 0.0
            anchored_all = False


        reset = win[key][1]
        out[key] = {
            "pct": max(0.0, pct),
            "cost": seen[key],
            "limit": limit,
            # A seeded ceiling is a guess; showing "$300 of $1500" would dress
            # it up as a measurement. Callers show the spend alone instead.
            "limit_known": bool(data["buckets"].get(key, {}).get("limit_from")),
            "reset": int((reset - now).total_seconds() // 60) if reset else 0,
        }

    if dirty:
        save_calib(data)

    # ---- confidence -----------------------------------------------------
    if live_all:
        conf = CONF_LIVE
    elif not data.get("calibrated_at"):
        conf = 0
    elif not anchored_all:
        conf = 1
    elif oldest_anchor and (now - oldest_anchor).total_seconds() > FRESH_HOURS * 3600:
        conf = 2
    else:
        conf = 3

    # ---- burn rate and time to the binding ceiling ----------------------
    recent = [e for e in events if (now - e[0]).total_seconds() <= 900]
    burn_hr = sum(e[3] for e in recent) * 4.0
    fb_burn = sum(e[3] for e in recent if is_fable(e[1])) * 4.0

    etas = []
    for key in BUCKETS:
        b = out[key]
        remaining = b["limit"] * (100.0 - b["pct"]) / 100.0
        rate = fb_burn if key == "fable" else burn_hr
        cap = b["reset"] if b["reset"] > 0 else 1 << 30
        etas.append(_eta(remaining, rate, cap))
    live = [e for e in etas if e >= 0]
    eta = min(live) if live else -1

    waiting, waiting_what = attention(now)
    worst = max(out[k]["pct"] for k in BUCKETS)
    idle_s = (now - events[-1][0]).total_seconds() if events else 1e9
    if any((now - t).total_seconds() < 3600 for t, _ in scanner.limit_hits):
        state = LIMITED
    elif worst >= 90:
        state = CRIT
    elif worst >= 75:
        state = WARN
    elif idle_s < 300:
        state = ACTIVE
    else:
        state = IDLE

    models, projects = defaultdict(float), defaultdict(float)
    for t, mod, proj, c in events:
        if t >= win["week"][0]:
            models[mod] += c
            projects[proj] += c

    return {
        "sess_pct": out["session"]["pct"], "sess_cost": out["session"]["cost"],
        "sess_limit": out["session"]["limit"], "sess_reset": out["session"]["reset"],
        "sess_limit_known": out["session"]["limit_known"],
        "wk_pct": out["week"]["pct"], "wk_cost": out["week"]["cost"],
        "wk_limit": out["week"]["limit"], "wk_reset": out["week"]["reset"],
        "wk_limit_known": out["week"]["limit_known"],
        "fb_pct": out["fable"]["pct"], "fb_cost": out["fable"]["cost"],
        "fb_limit": out["fable"]["limit"],
        "fb_limit_known": out["fable"]["limit_known"],
        "burn_hr": burn_hr, "eta": eta, "state": state,
        "conf": conf, "calibrated": bool(data.get("calibrated_at")) and anchored_all,
        "live": live_all, "source": source,
        "attention": waiting, "attention_what": waiting_what,
        # bit per bucket, so the panel can mark the ones it only estimated
        "live_mask": sum(1 << i for i, k in enumerate(BUCKETS)
                         if k in live or k in desk_anchor),
        "live_note": ("%s; desktop sample %.0f min old" % (source, desk["age_s"] / 60)
                      if desk else "%s; %s" % (source, live_usage.describe())),
        "models": _top(models, 4, short_model), "projects": _top(projects, 3),
        "now": now,
    }
