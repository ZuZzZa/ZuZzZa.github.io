#!/usr/bin/env python3
"""Guards the host<->firmware wire format.

The firmware parser cannot run here, so instead of duplicating its
expectations this reads them back out of src/main.cpp. If either side of the
protocol changes alone, this fails.

  python3 host/test_protocol.py
"""
import os
import re
import sys
import datetime as dt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from claude_meter import build_frames                     # noqa: E402

FIRMWARE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "src", "main.cpp")

SAMPLE = {
    "sess_pct": 93.4, "sess_cost": 199.02, "sess_limit": 423.0, "sess_reset": 207,
    "sess_limit_known": True,
    "wk_pct": 44.0, "wk_cost": 260.76, "wk_limit": 1500.0, "wk_reset": 1017,
    "wk_limit_known": False,
    "fb_pct": 77.0, "fb_cost": 156.07, "fb_limit": 203.0, "fb_limit_known": True,
    "burn_hr": 34.6, "eta": 27, "state": 3, "conf": 4, "calibrated": True,
    "live": True, "source": "desktop cache", "live_note": "desktop cache",
    "attention": True, "attention_what": "permission: Bash", "live_mask": 3,
    "models": [("Opus5", 62, 161.7), ("Fable5", 20, 52.2),
               ("Opus4.8", 12, 31.3), ("Haiku", 6, 15.6)],
    "projects": [("esp32-wro", 54, 140.8), ("zuzzza-gh", 28, 73.0),
                 ("onair", 18, 46.9)],
    "now": dt.datetime(2026, 8, 22, 15, 35, tzinfo=dt.timezone.utc),
}

failures = []


def check(cond, msg):
    if not cond:
        failures.append(msg)


src = open(os.path.abspath(FIRMWARE)).read()
frames = build_frames(SAMPLE)
by_kind = {f[0]: f for f in frames}

# --- G frame: field count must match the firmware's parser bounds ---
g_fields = by_kind["G"].split("|")[1:]
decl = re.search(r"long v\[(\d+)\];", src)
guard = re.search(r"if \(i < (\d+)\) return;", src)
loop = re.search(r"while \(tok && i < (\d+)\)", src)
check(decl and guard and loop, "could not read the G-frame parser out of main.cpp")
if decl and guard and loop:
    n = int(decl.group(1))
    check(int(guard.group(1)) == n and int(loop.group(1)) == n,
          "main.cpp disagrees with itself: v[%s], guard %s, loop %s"
          % (decl.group(1), guard.group(1), loop.group(1)))
    check(len(g_fields) == n,
          "host sends %d G fields, firmware expects %d" % (len(g_fields), n))

check(all(re.fullmatch(r"-?\d+", f) for f in g_fields),
      "G fields must all be plain integers: %r" % (g_fields,))

# atol() into a long, then stored in uint16_t / int16_t members
for i, f in enumerate(g_fields):
    check(-32768 <= int(f) <= 65535, "G field %d out of 16-bit range: %s" % (i, f))

# --- slice frames: names must fit Slice.name ---
cap = re.search(r"char name\[(\d+)\];", src)
check(cap is not None, "could not read Slice.name size out of main.cpp")
if cap:
    maxlen = int(cap.group(1)) - 1
    for kind in ("M", "P"):
        for part in by_kind[kind].split("|")[1:]:
            fields = part.split(",")
            check(len(fields) == 3,
                  "%s row %r must be name,percent,tenths" % (kind, part))
            name, pct, deci = fields[0], fields[1], fields[2]
            check(len(name) <= maxlen,
                  "%s name %r exceeds firmware capacity of %d" % (kind, name, maxlen))
            check(0 <= int(pct) <= 255, "%s pct %s does not fit uint8_t" % (kind, pct))
            check(0 <= int(deci) <= 65535, "%s amount %s does not fit uint16_t" % (kind, deci))

# --- row counts must fit the firmware's fixed arrays ---
for kind, member in (("M", "models"), ("P", "projects")):
    cnt = re.search(r"Slice %s\[(\d+)\];" % member, src)
    check(cnt is not None, "could not read %s[] size out of main.cpp" % member)
    if cnt:
        check(len(by_kind[kind].split("|")) - 1 <= int(cnt.group(1)),
              "%s frame carries more rows than firmware %s[%s]" % (kind, member, cnt.group(1)))

# --- every frame must be a single short line ---
for f in frames:
    check("\n" not in f and len(f) < 150, "frame too long or multi-line: %r" % f)
    check(len(f) > 1 and f[1] == "|", "frame must start with kind + '|': %r" % f)

if failures:
    print("FAIL")
    for f in failures:
        print("  - " + f)
    sys.exit(1)
print("ok: %d frames match src/main.cpp" % len(frames))
for f in frames:
    print("  " + f)
