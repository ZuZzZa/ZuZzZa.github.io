"""Reads Claude Code/Desktop transcripts and derives usage windows.

Everything here is computed from local JSONL under ~/.claude/projects.
No network, no API keys.
"""
import json
import os
import glob
import datetime as dt
from collections import defaultdict

CLAUDE_PROJECTS = os.path.expanduser("~/.claude/projects")

# $ per 1M tokens: (input, output). Verified 2026-06-24 pricing table.
PRICING = {
    "claude-fable-5":    (10.0, 50.0),
    "claude-mythos-5":   (10.0, 50.0),
    "claude-opus-5":     (5.0, 25.0),
    "claude-opus-4-8":   (5.0, 25.0),
    "claude-opus-4-7":   (5.0, 25.0),
    "claude-opus-4-6":   (5.0, 25.0),
    "claude-opus-4-5":   (5.0, 25.0),
    "claude-sonnet-5":   (3.0, 15.0),
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-sonnet-4-5": (3.0, 15.0),
    "claude-haiku-4-5":  (1.0, 5.0),
}
DEFAULT_PRICE = (5.0, 25.0)          # unknown model -> assume Opus tier
CACHE_WRITE_5M = 1.25                # x input
CACHE_WRITE_1H = 2.00                # x input
CACHE_READ     = 0.10                # x input

BLOCK_HOURS = 5
WEEK_DAYS = 7

# Short display names for the 480x320 panel.
SHORT = {
    "claude-fable-5": "Fable5", "claude-mythos-5": "Myth5",
    "claude-opus-5": "Opus5", "claude-opus-4-8": "Opus4.8",
    "claude-opus-4-7": "Opus4.7", "claude-opus-4-6": "Opus4.6",
    "claude-opus-4-5": "Opus4.5", "claude-sonnet-5": "Son5",
    "claude-sonnet-4-6": "Son4.6", "claude-sonnet-4-5": "Son4.5",
    "claude-haiku-4-5": "Haiku",
}


def short_model(m):
    return SHORT.get(m, (m or "?").replace("claude-", "")[:8])


def short_project(dirname):
    """-Users-igor-Documents-PlatformIO-Projects-esp32-wroom32-slave -> esp32-wroom32-slave"""
    name = dirname.rstrip("-").split("-")[-1] if dirname else "?"
    parts = [p for p in dirname.split("-") if p]
    # take the trailing path component of the encoded cwd
    for anchor in ("Projects", "Documents", "src"):
        if anchor in parts:
            tail = parts[parts.index(anchor) + 1:]
            if tail:
                return "-".join(tail)[:16]
    return name[:16]


def cost_of(model, u):
    """Dollar cost of one assistant message from its usage block."""
    pin, pout = PRICING.get(model, DEFAULT_PRICE)
    cc = u.get("cache_creation") or {}
    w5 = cc.get("ephemeral_5m_input_tokens") or 0
    w1 = cc.get("ephemeral_1h_input_tokens") or 0
    if not (w5 or w1):
        # older transcripts only carry the flat field
        w5 = u.get("cache_creation_input_tokens") or 0
    return (
        (u.get("input_tokens") or 0) * pin
        + w5 * pin * CACHE_WRITE_5M
        + w1 * pin * CACHE_WRITE_1H
        + (u.get("cache_read_input_tokens") or 0) * pin * CACHE_READ
        + (u.get("output_tokens") or 0) * pout
    ) / 1e6


class Scanner:
    """Incremental tail-reader over every transcript file."""

    def __init__(self, root=CLAUDE_PROJECTS):
        self.root = root
        self.offsets = {}
        self.events = []      # (ts, model, project, cost)
        self.limit_hits = []  # (ts, text)

    def poll(self):
        added = 0
        for path in glob.glob(os.path.join(self.root, "*", "*.jsonl")):
            try:
                size = os.path.getsize(path)
            except OSError:
                continue
            off = self.offsets.get(path, 0)
            if size <= off:
                if size < off:
                    self.offsets[path] = 0   # file was truncated/rotated
                continue
            project = short_project(os.path.basename(os.path.dirname(path)))
            try:
                with open(path, "r", errors="ignore") as fh:
                    fh.seek(off)
                    for line in fh:
                        if not line.endswith("\n"):
                            break            # partial write; re-read next poll
                        off += len(line.encode("utf-8", "ignore"))
                        added += self._ingest(line, project)
                    self.offsets[path] = off
            except OSError:
                continue
        if added:
            self.events.sort(key=lambda e: e[0])
            self.limit_hits.sort()
        return added

    def _ingest(self, line, project):
        try:
            d = json.loads(line)
        except ValueError:
            return 0
        ts = d.get("timestamp")
        if not ts:
            return 0
        try:
            when = dt.datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            return 0
        if d.get("error") == "rate_limit":
            content = (d.get("message") or {}).get("content") or []
            txt = "".join(c.get("text", "") for c in content if isinstance(c, dict))
            self.limit_hits.append((when, txt))
        msg = d.get("message") or {}
        u = msg.get("usage")
        if not u or d.get("type") != "assistant":
            return 0
        model = msg.get("model") or "?"
        if model == "<synthetic>":
            return 0
        c = cost_of(model, u)
        if c <= 0:
            return 0
        self.events.append((when, model, project, c))
        return 1


def five_hour_blocks(events):
    """ccusage-style blocks: start floored to the hour, closed by 5h elapsed or a 5h gap."""
    blocks = []
    cur = None
    for when, model, project, c in events:
        if cur is None or when >= cur["end"] or (when - cur["last"]).total_seconds() > BLOCK_HOURS * 3600:
            start = when.replace(minute=0, second=0, microsecond=0)
            cur = {"start": start, "end": start + dt.timedelta(hours=BLOCK_HOURS),
                   "last": when, "cost": 0.0, "models": defaultdict(float),
                   "projects": defaultdict(float)}
            blocks.append(cur)
        cur["last"] = when
        cur["cost"] += c
        cur["models"][model] += c
        cur["projects"][project] += c
    return blocks
