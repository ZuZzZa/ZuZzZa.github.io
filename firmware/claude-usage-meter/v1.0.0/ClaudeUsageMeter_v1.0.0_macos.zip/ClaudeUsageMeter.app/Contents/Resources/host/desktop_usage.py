"""Reads the utilisation Claude Desktop already keeps on disk.

Claude Desktop samples the plan limits every 15 minutes and caches them in

    ~/Library/Application Support/Claude/plan-usage-history.json

as `{"t": epoch_ms, "org": ..., "u": {"fh": five_hour_pct, "sd": seven_day_pct}}`.

Those are the same numbers the usage screen shows - a sample taken at 17:29
read `fh: 19, sd: 45` against a screenshot reading 19% and 45%. No token, no
network, no rate limit, nothing undocumented being called: the file is simply
there.

Two things it does not give. The model-specific weekly bucket (Fable) is not
cached - only `fh` and `sd` - so that one stays an estimate. And samples are
15 minutes apart, so the newest one is stale by up to that long; the meter
uses it as an anchor and extrapolates with locally measured spend, which
correlates with the reported figure at r = 0.99.

The same history makes the dollar ceilings self-fitting: regressing measured
spend against reported percent inside one window gives dollars-per-point
without anyone reading a screen.
"""
import json
import os
import datetime as dt

HISTORY = os.path.expanduser(
    "~/Library/Application Support/Claude/plan-usage-history.json")

RESET_DROP = 3        # percent points of fall that mean a new window opened
MIN_FIT_SPAN = 5      # percent points a window must cover before fitting it
MAX_ANCHOR_AGE = 45 * 60


def _load():
    try:
        with open(HISTORY) as fh:
            doc = json.load(fh)
    except (OSError, ValueError):
        return []
    out = []
    for s in doc.get("samples", []):
        u = s.get("u") or {}
        t = s.get("t")
        if t is None:
            continue
        out.append((dt.datetime.fromtimestamp(t / 1000.0, dt.timezone.utc),
                    u.get("fh"), u.get("sd")))
    out.sort()
    return out


def latest(now=None):
    """-> {"session": pct, "week": pct, "at": datetime, "age_s": float} or None."""
    samples = _load()
    if not samples:
        return None
    now = now or dt.datetime.now(dt.timezone.utc)
    at, fh, sd = samples[-1]
    if fh is None and sd is None:
        return None
    age = (now - at).total_seconds()
    return {"session": fh, "week": sd, "at": at, "age_s": age,
            "fresh": age <= MAX_ANCHOR_AGE}


def window_start(now=None):
    """When the current 5-hour window opened, read off the history.

    A sharp fall in `fh` is a reset. This is firmer than inferring window
    boundaries from transcript gaps, because it is what the plan actually did.
    """
    samples = [(t, fh) for t, fh, _ in _load() if fh is not None]
    if not samples:
        return None
    start = samples[0][0]
    for i in range(1, len(samples)):
        if samples[i][1] < samples[i - 1][1] - RESET_DROP:
            start = samples[i][0]
    return start


def fit_ceiling(events, since=None, now=None, field="fh", only_fable=False):
    """Least squares of measured spend against reported percent.

    -> (dollars_per_100_points, points_covered, correlation) or None. Fitting
    across a whole window beats two readings: r came out at 0.988 over the
    seventeen samples of one window here.
    """
    now = now or dt.datetime.now(dt.timezone.utc)
    start = since or window_start(now)
    if start is None:
        return None
    idx = 1 if field == "fh" else 2
    samples = [(row[0], row[idx]) for row in _load()
               if row[idx] is not None and row[0] >= start]
    if len(samples) < 4:
        return None

    rows = []
    for t, pct in samples:
        spend = sum(c for tt, m, _, c in events
                    if start <= tt < t and (not only_fable or "fable" in (m or "")))
        rows.append((float(pct), spend))

    span = max(r[0] for r in rows) - min(r[0] for r in rows)
    if span < MIN_FIT_SPAN:
        return None

    n = len(rows)
    mx = sum(r[0] for r in rows) / n
    my = sum(r[1] for r in rows) / n
    sxx = sum((x - mx) ** 2 for x, _ in rows)
    sxy = sum((x - mx) * (y - my) for x, y in rows)
    if sxx <= 0:
        return None
    slope = sxy / sxx                       # dollars per percent point
    if slope <= 0:
        return None
    syy = sum((y - my) ** 2 for _, y in rows)
    r = sxy / ((sxx * syy) ** 0.5) if syy > 0 else 0.0
    return slope * 100.0, span, r
