#!/usr/bin/env python3
"""Records when Claude Code is waiting on you, for the panel to blink about.

Wired to Claude Code hooks in ~/.claude/settings.json:

    set   <- Stop, Notification, PermissionRequest
    clear <- UserPromptSubmit, PostToolUse

`Stop` is the one that matters most: in auto mode a classifier decides most
permissions and no dialog is ever shown, so `PermissionRequest` may never
fire - but "Claude finished and is waiting for you" always happens. Clearing
on `PostToolUse` is what makes a granted permission stop the blink, since the
tool having run is proof the dialog was answered.

One marker file per session, under attention/, so the panel can say how many
sessions are waiting rather than just that one is. Sessions that never report
an id share the `default` slot.

Hooks receive their payload as JSON on stdin. This reads it opportunistically:
a hook that dies on malformed input would take the turn down with it, so
every failure here is swallowed.

    python3 attention_hook.py set|clear
"""
import json
import os
import re
import sys
import time

STATE_DIR = os.path.expanduser("~/.claude-usage-meter")
ATTENTION_DIR = os.path.join(STATE_DIR, "attention")
LEGACY_MARKER = os.path.join(STATE_DIR, "attention.json")
SAFE = re.compile(r"[^A-Za-z0-9._-]")


def read_payload():
    if sys.stdin.isatty():
        return {}
    try:
        raw = sys.stdin.read()
    except Exception:
        return {}
    try:
        return json.loads(raw) if raw.strip() else {}
    except ValueError:
        return {}


def slot(payload):
    """A filename-safe key for this session."""
    sid = str(payload.get("session_id") or "").strip()
    return (SAFE.sub("", sid)[:64] or "default") + ".json"


def summarise(payload):
    """A short label for the menu; the panel only needs the count."""
    for key in ("message", "notification", "reason"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()[:120]
    tool = payload.get("tool_name")
    return ("permission: " + tool) if tool else "input needed"


def main():
    action = sys.argv[1] if len(sys.argv) > 1 else "set"
    payload = read_payload()
    path = os.path.join(ATTENTION_DIR, slot(payload))
    try:
        os.makedirs(ATTENTION_DIR, exist_ok=True)
        if action == "clear":
            for stale in (path, LEGACY_MARKER):
                if os.path.exists(stale):
                    os.remove(stale)
        else:
            tmp = path + ".tmp"
            with open(tmp, "w") as fh:
                json.dump({"at": time.time(),
                           "what": summarise(payload),
                           "cwd": payload.get("cwd", "")}, fh)
            os.replace(tmp, path)
    except OSError:
        pass          # never let a blinking light break a Claude Code turn
    return 0


if __name__ == "__main__":
    sys.exit(main())
