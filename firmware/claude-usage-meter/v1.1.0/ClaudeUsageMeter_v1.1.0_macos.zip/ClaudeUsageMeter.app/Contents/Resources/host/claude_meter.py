#!/usr/bin/env python3
"""Feeds Claude usage to the Arduino panel over USB serial.

  python3 claude_meter.py --dry-run        # terminal preview, no hardware
  python3 claude_meter.py                  # auto-detect the Mega and stream
  python3 claude_meter.py --port /dev/cu.usbmodem1401

Wire format is line-oriented ASCII so it can be watched with a serial monitor:

  G|spct|sdeci|slim|sreset|wpct|wdeci|wlim|wreset|fpct|fdeci|flim|burn|eta|state|conf|att|src|pace|night
  D|weekday|d1|..|d7             seven local days of spend, oldest first
  M|Opus5,62|Fable5,20|...        model split of the current window
  P|esp32-slave,54|...            project split of the current window
  T|HH:MM|Sat 22 Aug              host clock and date, for the standby screen

Costs travel as tenths of a dollar; percentages and minutes as integers.
"""
import argparse
import glob
import json
import re
import subprocess
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from usage import Scanner
from meter import snapshot, calibrate, load_calib, STATE_DIR

BAUD = 115200
board_version = ""      # what the panel reports; "" until it says
STATE_NAMES = ["IDLE", "ACTIVE", "WARN", "CRIT", "LIMITED"]
CONF_NAMES = ["guess", "low", "med", "high", "live"]


def d10(x):
    """Dollars -> tenths, clamped to what a uint16 can carry."""
    return max(0, min(65535, int(round(x * 10))))


def build_frames(s):
    g = "G|" + "|".join(str(v) for v in (
        min(999, int(round(s["sess_pct"]))), d10(s["sess_cost"]),
        d10(s["sess_limit"]) if s["sess_limit_known"] else 0,
        max(0, s["sess_reset"]),
        min(999, int(round(s["wk_pct"]))), d10(s["wk_cost"]),
        d10(s["wk_limit"]) if s["wk_limit_known"] else 0,
        max(0, s["wk_reset"]),
        min(999, int(round(s["fb_pct"]))), d10(s["fb_cost"]),
        d10(s["fb_limit"]) if s["fb_limit_known"] else 0,
        d10(s["burn_hr"]), s["eta"], s["state"], s["conf"],
        s["attention"], s["live_mask"],
        s["pace"], 1 if s["night"] else 0,
    ))
    m = "M" + "".join("|%s,%d,%d" % (n[:9], p, d10(c)) for n, p, c in s["models"])
    p = "P" + "".join("|%s,%d,%d" % (n[:9], p, d10(c)) for n, p, c in s["projects"])
    when = s["now"].astimezone()
    d = "D|%d" % s["history_weekday"] + "".join("|%d" % d10(v) for v in s["history"])
    t = "T|" + when.strftime("%H:%M") + "|" + when.strftime("%a %d %b")
    return [g, m, p, d, t]


STATUS_PATH = os.path.join(STATE_DIR, "status.json")


def read_version():
    """The root VERSION file, or the copy the app bundle carries beside us."""
    here = os.path.dirname(os.path.abspath(__file__))
    for candidate in (os.path.join(here, "VERSION"),
                      os.path.join(here, os.pardir, "VERSION")):
        try:
            with open(candidate) as fh:
                return fh.read().strip()
        except OSError:
            continue
    return "0.0.0-dev"


VERSION = read_version()
LOCK_PATH = os.path.join(STATE_DIR, "daemon.pid")


def log(msg):
    """Timestamped, unbuffered - the log is read after the fact, when the
    ordering of reconnects is the whole question."""
    print("%s  %s" % (time.strftime("%H:%M:%S"), msg), file=sys.stderr, flush=True)


def another_daemon_running():
    """Two daemons on one serial port fight over it and confuse each other's
    reconnects. Orphans are easy to create - the menu bar app only tracks the
    child it started, so a crashed app leaves one behind."""
    try:
        with open(LOCK_PATH) as fh:
            pid = int(fh.read().strip())
    except (OSError, ValueError):
        return None
    if pid == os.getpid():
        return None
    try:
        out = subprocess.run(["ps", "-p", str(pid), "-o", "command="],
                             capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    return pid if "claude_meter.py" in out else None


def claim_lock():
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(LOCK_PATH, "w") as fh:
        fh.write(str(os.getpid()))


def write_status(s, connected, port):
    """Publishes the current reading for the menu bar app to pick up.

    Written atomically every cycle: the app polls this file rather than
    parsing the daemon's stdout, so the two stay decoupled.
    """
    when = s["now"].astimezone()
    doc = {
        "updated": time.time(),
        "version": VERSION,
        "firmware_version": board_version,
        "version_ok": (not board_version) or board_version == VERSION,
        "pace": s["pace"],
        "night": bool(s["night"]),
        "notify_at": s["config"]["notify_at"],
        "clock": when.strftime("%H:%M"),
        "date": when.strftime("%a %d %b"),
        "connected": bool(connected),
        "port": port or "",
        "state": s["state"],
        "state_name": STATE_NAMES[s["state"]],
        "conf": s["conf"],
        "conf_name": CONF_NAMES[s["conf"]],
        "live": bool(s["live"]),
        "source": s["source"],
        "attention": int(s["attention"]),      # sessions waiting, not a flag
        "attention_what": s["attention_what"],
        "live_note": s["live_note"],
        "calibrated": bool(s["calibrated"]),
        "burn_hr": round(s["burn_hr"], 2),
        "eta": s["eta"],
        "buckets": [
            {"key": "session", "label": "5-hour", "pct": round(s["sess_pct"], 1),
             "cost": round(s["sess_cost"], 2),
             "limit": round(s["sess_limit"], 2) if s["sess_limit_known"] else None,
             "reset": s["sess_reset"]},
            {"key": "week", "label": "Week all", "pct": round(s["wk_pct"], 1),
             "cost": round(s["wk_cost"], 2),
             "limit": round(s["wk_limit"], 2) if s["wk_limit_known"] else None,
             "reset": s["wk_reset"]},
            {"key": "fable", "label": "Week Fable", "pct": round(s["fb_pct"], 1),
             "cost": round(s["fb_cost"], 2),
             "limit": round(s["fb_limit"], 2) if s["fb_limit_known"] else None,
             "reset": s["wk_reset"]},
        ],
        "models": [{"name": n, "pct": p, "cost": round(c, 2)} for n, p, c in s["models"]],
        "projects": [{"name": n, "pct": p, "cost": round(c, 2)}
                     for n, p, c in s["projects"]],
        "history": [round(v, 2) for v in s["history"]],
        "history_weekday": s["history_weekday"],
    }
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        tmp = STATUS_PATH + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(doc, fh)
        os.replace(tmp, STATUS_PATH)
    except OSError:
        pass          # the panel matters more than the menu bar


def bar(pct, width=34):
    fill = max(0, min(width, int(round(width * pct / 100.0))))
    return "[" + "#" * fill + "-" * (width - fill) + "]"


def render(s):
    def hm(mins):
        return "--" if mins <= 0 else "%dh%02dm" % (mins // 60, mins % 60)

    def row(label, pct, cost, limit, known, mins, when):
        amount = "$%.2f of $%.0f" % (cost, limit) if known else "$%.2f" % cost
        return ["  %-12s %5.1f%%  %s" % (label, pct, bar(pct)),
                "     %s%s%s %s" % (amount, " " * 6, when, hm(mins))]

    head = "  CLAUDE USAGE            %s   %s" % (
        s["now"].astimezone().strftime("%H:%M"), STATE_NAMES[s["state"]])
    if s["attention"]:
        head += "   << NEEDS YOU: %s" % (s["attention_what"] or "input")
    out = [head, "  " + "-" * 46]
    out += row("5-HOUR", s["sess_pct"], s["sess_cost"], s["sess_limit"],
               s["sess_limit_known"], s["sess_reset"], "resets in")
    out += [""]
    out += row("WEEK ALL", s["wk_pct"], s["wk_cost"], s["wk_limit"],
               s["wk_limit_known"], s["wk_reset"], "resets in")
    out += [""]
    out += row("WEEK FABLE", s["fb_pct"], s["fb_cost"], s["fb_limit"],
               s["fb_limit_known"], s["wk_reset"], "resets in")
    out += [
        "",
        "  BURN $%.1f/h        LIMIT ETA %s      calib: %s%s"
        % (s["burn_hr"], "--" if s["eta"] < 0 else hm(s["eta"]),
           CONF_NAMES[s["conf"]],
           "" if (s["live"] or s["calibrated"]) else " (uncalibrated)"),
        "  " + "-" * 46,
        "  MODELS    " + ("  ".join("%s $%.0f (%d%%)" % (n, c, p)
                                    for n, p, c in s["models"]) or "-"),
        "  PROJECTS  " + ("  ".join("%s $%.0f (%d%%)" % (n, c, p)
                                    for n, p, c in s["projects"]) or "-"),
    ]
    return "\n".join(out)


DURATION = re.compile(r"^(?:(\d+)h)?\s*(?:(\d+)m)?$")


def parse_reading(text, with_reset=True):
    """'11,3h27m' -> (11.0, 207) ; '77' -> (77.0, None)"""
    parts = [p.strip() for p in text.split(",")]
    pct = float(parts[0].rstrip("%"))
    if not with_reset or len(parts) < 2:
        return pct, None
    m = DURATION.match(parts[1])
    if not m or not any(m.groups()):
        raise SystemExit("bad reset time %r - use forms like 3h27m, 16h57m, 45m"
                         % parts[1])
    return pct, int(m.group(1) or 0) * 60 + int(m.group(2) or 0)


def find_port():
    cands = []
    for pat in ("/dev/cu.usbmodem*", "/dev/cu.usbserial*", "/dev/cu.wchusbserial*",
                "/dev/cu.SLAB_USBtoUART*"):
        cands += glob.glob(pat)
    return cands[0] if cands else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", action="version",
                    version="claude-usage-meter %s" % VERSION)
    ap.add_argument("--port")
    ap.add_argument("--dry-run", action="store_true", help="print the panel to the terminal")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=float, default=5.0)
    ap.add_argument("--calibrate", action="store_true",
                    help="pin the ceilings from one reading of the Claude usage screen")
    ap.add_argument("--session", metavar="PCT,RESET",
                    help="current session, e.g. 11,3h27m")
    ap.add_argument("--week", metavar="PCT,RESET",
                    help="weekly all models, e.g. 44,16h57m")
    ap.add_argument("--fable", metavar="PCT", help="weekly Fable, e.g. 77")
    args = ap.parse_args()

    scanner = Scanner()
    scanner.poll()

    if args.calibrate:
        if not (args.session or args.week):
            sys.exit("--calibrate needs --session and/or --week "
                     "(read them off the Claude usage screen)")
        session = parse_reading(args.session) if args.session else None
        week = parse_reading(args.week) if args.week else None
        fable = parse_reading(args.fable, with_reset=False)[0] if args.fable else None
        report = calibrate(scanner.events, session, week, fable)

        print("anchored to the usage screen:")
        labels = {"session": "5-hour", "week": "week, all models", "fable": "week, Fable"}
        for key in ("session", "week", "fable"):
            r = report.get(key)
            if not r:
                continue
            note = ("ceiling refitted to $%.0f (%s)" % (r["fitted"], "two readings")
                    if r["fitted"] else "ceiling kept at $%.0f" % r["limit"])
            print("  %-17s %3g%% reported, $%.2f visible   %s"
                  % (labels[key], r["pct"], r["visible"], note))
        print()
        print("Between calibrations only usage this tool can see is added, so the")
        print("figures drift low if you also chat with Claude outside Claude Code.")
        print("Re-run after 2026-08-31: the +50% weekly boost ends then.")
        return

    calib = None

    if args.dry_run:
        run_preview(scanner, calib, args)
        return

    try:
        import serial
    except ImportError:
        sys.exit("pyserial missing: python3 -m pip install --user pyserial")

    other = another_daemon_running()
    if other:
        sys.exit("another daemon already owns the port (pid %d); not starting a second"
                 % other)
    claim_lock()

    # The board browns out if the shield's backlight drags the 5V rail down,
    # and the USB bridge then re-enumerates, so the port can vanish mid-write.
    # Losing the link is routine here, not fatal - reopen and carry on.
    ser = None
    last_send = 0.0
    while True:
        try:
            if ser is None:
                port = args.port or find_port()
                if not port:
                    log("no serial port; waiting for the board")
                    scanner.poll()
                    write_status(snapshot(scanner), False, None)
                    time.sleep(3.0)
                    continue
                ser = serial.Serial(port, BAUD, timeout=0.2)
                ser.reset_input_buffer()   # drop bytes from before we opened
                time.sleep(2.0)            # opening the port resets the board
                last_send = 0.0          # first frame goes out immediately
                log("streaming to %s" % port)

            # Answer the board's request the moment it arrives; otherwise
            # send on the regular cadence. Polling at 0.2 s keeps a reset from
            # costing a whole interval of "waiting for host".
            asked = False
            while ser.in_waiting:
                line = ser.readline().decode("utf-8", "ignore").strip()
                if not line:
                    continue
                if line == "?":
                    asked = True
                elif line.startswith("V|"):
                    global board_version
                    reported = line[2:].strip()
                    if reported and reported != board_version:
                        board_version = reported
                        if board_version == VERSION:
                            log("firmware v%s matches" % board_version)
                        else:
                            log("VERSION MISMATCH: app %s, firmware %s - reflash "
                                "the board" % (VERSION, board_version))
                else:
                    log("[dev] " + line)

            now = time.monotonic()
            if asked or now - last_send >= args.interval:
                scanner.poll()
                snap = snapshot(scanner)
                for f in build_frames(snap):
                    ser.write((f + "\n").encode())
                ser.flush()
                write_status(snap, True, ser.port)
                last_send = time.monotonic()

            if args.once:
                break
            time.sleep(0.2)

        except (OSError, serial.SerialException) as exc:
            log("link lost (%s); reconnecting" % exc)
            try:
                write_status(snapshot(scanner), False, None)
            except Exception:
                pass
            try:
                ser.close()
            except Exception:
                pass
            ser = None
            time.sleep(3.0)
        except KeyboardInterrupt:
            break

    if ser:
        ser.close()


def run_preview(scanner, calib, args):
    try:
        while True:
            scanner.poll()
            s = snapshot(scanner)
            if not args.once:
                sys.stdout.write("\033[2J\033[H")
            print(render(s))
            print("\n  wire:\n    " + "\n    ".join(build_frames(s)))
            write_status(s, False, None)
            if args.once:
                break
            time.sleep(args.interval)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
